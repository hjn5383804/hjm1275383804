import ctypes, os


class NetWortk(object):
    def __init__(self, itf):
        try:
            assert ctypes.windll.shell32.IsUserAnAdmin() == 1
            print("已经以管理员权限运行")
        except:
            raise EOFError("python.exe需要开启管理员权限")
        self.itf = itf

    def set_dhcp(self):
        os.system('netsh interface ip set address "{}" dhcp'.format(self.itf))

    def set_auto_dns(self):

        os.system('netsh interface ip set dns "{}" dhcp'.format(self.itf))

    def set_static_dns(self, dns1, dns2=None):
        os.system('netsh interface ip set dns "{}"  static {}'.format(self.itf, dns1,))
        os.system('netsh interface ip add dns name="{}" addr ={}'.format(self.itf, dns2))

    def set_static_ip(self, ip, mask, gateway=None):
        os.system('netsh interface ip set address "{}" static {} {} {}'.format(self.itf, ip, mask, gateway))

    def release(self):
        os.system('ipconfig /release')

    def renew(self):
        os.system('ipconfig /renew')
# NetWortk('以太网').set_static_ip('192.168.0.123','255.255.255.0')
NetWortk('以太网').set_dhcp()
# NetWortk('以太网').release()
# NetWortk('以太网').renew()