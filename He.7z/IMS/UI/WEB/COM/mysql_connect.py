import random

import mysql.connector

mydb = mysql.connector.connect(
    host='ob-public-test-40100.chj.cloud',
    user='osd_hr_partnership_rw@public01#ob_public_test_40100',
    passwd='hX4uIK4@xzW6C#8zTQ5',
    database='osd_hr_partnership',
    port=3306
)
mycursor = mydb.cursor()
random_string='中文测试1234567890qwertyuiopasdfghjklzxcvbnm'
x=random.choices(random_string,k=32)

sql = 'UPDATE vendor_staff_info SET job_category_code ="V000159",job_sequence_code ="10224",job_new_post = "329新增岗位名称" ,job_new_level ="17" , job_category_name="329新增的类别",job_code = "OP0097",office_type = 1 WHERE vendor_staff_id =55505'

mycursor.execute(sql)

mydb.commit()  # 数据表内容有更新，必须使用到该语句
if mycursor.rowcount >= 1:
    print(mycursor.rowcount, "记录插入成功")
else:
    print('数据表未更新')


# url = 'http://httpbin.org/post'
# files = {'file': open('report.txt', 'rb')}
# r = requests.post(url, files=files)
# print r.text