import time

from playwright.sync_api import sync_playwright
with sync_playwright() as sp:
    chromium = sp.chromium
    browser = chromium.launch(channel="chrome",headless=False)
    context = browser.new_context()
    page=browser.new_page()
    # 会话开启监听
    # context.tracing.start(screenshots=True, snapshots=True, sources=True)

    page.goto("http://www.baidu.com")
    ele=page.locator('#s-usersetting-top').text_content()
    time.sleep(2)
    print(ele)
    # page.locator('#kw').fill('hjn131415')
    # page.locator('#su').click()

    # 结束监听并保存会话日志
    # context.tracing.stop(path="trace1233.zip")
    browser.close()