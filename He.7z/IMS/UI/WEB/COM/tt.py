import time

from selenium import webdriver
driver=webdriver.Chrome()
driver.get('https://www.baidu.com')
time.sleep(5)
driver.get('https://www.163.com')

time.sleep(5)

