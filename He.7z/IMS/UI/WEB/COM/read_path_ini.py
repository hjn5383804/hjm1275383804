import re
from configparser import ConfigParser
import os


class ReadPathIni:
    """只能WEB及其目录下调用"""
    def __init__(self):
        """将read_path_ini.py的父目录与data\path.ini目录进行拼接，得到path.ini文件的路径,
        with open打开ini文件，用以其余函数获取各自配置"""
        self.base_path = re.findall('(.+?WEB)', os.getcwd())[0]
        # 实例读取ini对象
        self.config = ConfigParser()
        ini_path = os.path.join(self.base_path, "data_config\path.ini")
        with open(ini_path, encoding="utf-8") as fp:
            self.config.read_file(fp)

    # 获取excel文件的绝对路径
    def get_excel_path(self, ini_params):
        """config.get需传入配置文件信息头、属性，返回属性值"""
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)

    # 获取Sheet名称
    def get_sheet_name(self, ini_params):
        return self.config.get("Path", ini_params)

    # 获取csv文件的绝对路径
    def get_csv_path(self, ini_params):
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)

    # 获取yaml文件的绝对路径
    def get_requests_json_path(self, ini_params):
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)

    # 获取json文件的绝对路径
    def get_expect_json_path(self, ini_params):
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)

    # 获取升级文件路径
    def get_software_path(self, ini_params):
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)

    # 获取其他普通文件路径
    def get_file_path(self, ini_params):
        relative_path = self.config.get("Path", ini_params)
        return os.path.join(self.base_path, relative_path)




if __name__ == '__main__':
    read_ini = ReadPathIni()
    # print(read_ini.get_excel_path('API_mould.xlsx'))
    # print(read_ini.get_requests_json_path('params.json'))
    # print(read_ini.get_expect_json_path('expect.json'))
    # print(read_ini.get_software_path('2431'))
    # print(read_ini.get_sheet_name('API_mould_sheet_name'))
    # 'D:\TENDA\IMS\UI\WEB\data_config\path.ini'
    print(read_ini.get_csv_path('ims_login.csv'))