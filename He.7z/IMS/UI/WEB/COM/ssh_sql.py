from sshtunnel import SSHTunnelForwarder
import pymysql

server = SSHTunnelForwarder(
		#跳板机IP，跳板机端口号
        ('118.31.104.150',22),
    ssh_username='root',
    ssh_pkey=r'x.pem',  #私钥文件位置
    # ssh_private_key_password='****',	#私钥密码(通行短语)
    remote_bind_address=('118.31.104.150',3306)				#远程数据库的IP和端口
)
server.start()
#host必须为127.0.0.1，代表本机(堡垒机)，user和passwd填的是远程数据库的账号密码
conn = pymysql.connect(host='127.0.0.1',port=server.local_bind_port,user='root',passwd='',db='ims')
#创建游标
cur = conn.cursor()
#执行sql语句
cur.execute('select * from tb_dev_mapping_statistics')
#返回所有结果
res = cur.fetchall()
print(res)
#关闭游标
cur.close()
#关闭连接
conn.close()
#关闭服务
server.close()
