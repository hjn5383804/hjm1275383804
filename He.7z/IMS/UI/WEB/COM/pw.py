from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    #channel浏览器类型，headless无头模式可生成PDF，slow_mo放慢执行速度
    browser = p.chromium.launch(channel="chrome",headless=False,slow_mo=100)

    context=browser.new_context()
    context2=browser.new_context()
    page = context.new_page()
    page2 = context.new_page()
    # page.goto('http://www.baidu.com')
    page2.goto('http://www.163.com')

    # p=context2.new_page()
    # p2=context2.new_page()
    # p3=context2.new_page()


    # time.sleep(5)


    # p.goto('http://118.178.252.225:8011/')
    # p2.goto('http://192.168.2.1')
    # p3.goto('http://www.taobao.com')
    # page.locator('#kw').fill('123456')
    # l=page.locator('#su')
    # l.click()
    # print(page.title)
    time.sleep(5)
    browser.close()

#窗口处理
# with page.expect_popup() as popup_info:
#     page.locator("#open").click()
# popup = popup_info.value
#
# popup.wait_for_load_state()
# print(popup.title())

