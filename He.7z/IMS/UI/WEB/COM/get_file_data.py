import yaml
import csv
import json
import openpyxl


class GetFileData:

    def get_csv(self,path):
        rows = []
        with open(path, encoding='gbk') as f:
            readers = csv.reader(f)
            for row in readers:
                rows.append(row)
            rows.pop(0)
        return rows

    def read_excel_data(self,path, sheet_name):
        # 打开表格
        global one_line_tpule
        lw = openpyxl.load_workbook(path)
        # 选择sheet页
        get_sheet = lw[sheet_name]
        list_data = []
        all_list = []
        start = True
        # 读数据
        for row_tuple in get_sheet:
            if start:
                start = False
                continue
            for i in row_tuple:
                list_data.append(i.value)
                one_line_tpule = tuple(list_data)
            # 清空之前转换的列表
            list_data.clear()
            all_list.append(one_line_tpule)
        return all_list

    def read_json_data(self,path):
        with open(path, encoding="utf8") as json_data:
            return json.load(json_data)

    def read_yaml_data(self,path):
        with open(path,mode="r",encoding="utf8") as yaml_data:
            return yaml.safe_load(yaml_data)


