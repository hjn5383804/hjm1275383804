import time

from playwright.sync_api import sync_playwright


with sync_playwright() as sp:
    chromium = sp.chromium
    browser = chromium.launch(channel="chrome",headless=False)
    page = browser.new_page()
    # 监听请求和响应事件
    page.on("request", lambda request: print(">>", request.method, request.url))
    page.on("response", lambda response: print("<<", response.status, response.url))
    page.goto("https://example.com")
    time.sleep(10)
    browser.close()
