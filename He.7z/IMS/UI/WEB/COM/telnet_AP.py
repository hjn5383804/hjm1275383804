import logging
import telnetlib
import time
import requests
def telnet(command,ip):
    global init_flag
    #先尝试telnet连接，获取连接结果
    tn = telnetlib.Telnet()
    try:
        tn.open(host='{}'.format(ip),port=23,timeout=3)
        init_flag = True
    except:
        logging.warning('网络连接失败')
        init_flag=False
    #失败则打开23端口
    if init_flag==False:
        session = requests.Session()
        params_login = {
            "sysLogin": {
                "username": "admin",
                "password": "YWRtaW4=",
                "logoff": "false",
            }
        }
        for i in range(3):
            resp = session.post('http://{}/goform/modules'.format(ip), json=params_login, timeout=10)
            resp_text = str(resp.text)
            exp = '{"sysLogin":{"userType":"admin","Login":true,"logoff":false}}'
            if exp == resp_text:
                print("DUT 23端口初始化成功")
                session.get('http://{}/goform/telnet'.format(ip))
                break
    #账号
    tn.open(host='{}'.format(ip), port=23, timeout=3)
    tn.read_until(b'login: ',timeout=3)
    tn.write("root".encode('ascii') + b'\n')
    #密码
    tn.read_until(b'Password: ',timeout=3)
    tn.write("Fireitup".encode('ascii') + b'\n')
    tn.write(command.encode('utf-8')+b'\n')
    time.sleep(2)
    # 获取命令结果
    r = tn.read_very_eager().decode('utf-8','ignore').replace(command,"").replace('root@W83AP:~#',"").replace('BusyBox v1.30.1 () built-in shell (ash)',"").replace('\n',"",6)
    # 退出telnet
    tn.write(b"exit")
    return r



