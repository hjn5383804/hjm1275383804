import pymysql
import redis


class ReadDtatBsae:

    def __init__(self, host, user, passwd, database, port):
        self.host = host
        self.user = user
        self.passwd = passwd
        self.database = database
        self.port = port

    def read_pymysql(self, sql):
        # 连接数据库
        my_connect = pymysql.connect(host=self.host,
                                     user=self.user,
                                     password=self.passwd,
                                     database=self.database,
                                     port=self.port,
                                     charset="utf8")
        # 建立游标
        data = my_connect.cursor()

        # 执行语句
        data.execute(sql)
        if data.lastrowid:
            print(f"Inserted record ID: {data.lastrowid}")

            # 若要查询并打印刚才插入的数据，你需要知道唯一标识这条记录的字段（比如ID）
        inserted_id = data.lastrowid  # 如果有自增长ID
        # 或者如果你插入了某个特定值作为唯一标识：
        # inserted_id = 'value1'

        # 查询刚插入的数据
        select_sql = f"SELECT * FROM vendor_staff_info WHERE id={inserted_id}"
        data.execute(select_sql)
        inserted_data = data.fetchone()
        print("Inserted data:", inserted_data)
        return data.fetchall()



# x=ReadDtatBsae(host='ob-public-test-40100.chj.cloud',user='osd_hr_partnership_rw@public01#ob_public_test_40100',passwd='hX4uIK4@xzW6C#8zTQ5',database='osd_hr_partnership',port=3306)
# print(x.read_pymysql('UPDATE vendor_staff_info SET job_category_code ="V00071", job_sequence_code ="10031",job_new_post = "实施工程师" ,job_new_level ="19" ,job_code = "V00071",office_type = 1 WHERE vendor_staff_id =70187'))
# print(x.read_pymysql('select * from vendor_staff_info'))


# class ReadRedis:
#     def __init__(self, host, port):
#         self.host = host
#         self.port = port
#         self.pool = redis.ConnectionPool(host=self.host, port=self.port, decode_responses=True)
#         self.r = redis.Redis(host=self.host, port=self.port, decode_responses=True)
#
#     def redis_set(self, key, value):
#         # 设置单个键值对
#         self.r.set(key, value)
#     def redis_get(self,key):
#         # 取出单个键对应的值
#         print(self.r.get(key))

conn = pymysql.connect(host='ob-public-test-40100.chj.cloud',
                       password='DiJ24kt*2nCq55E',
                       port=3306,
                       user='osd_hr_budget_vendor_rw@public#ob_public_test_40100',
                       database='hr_budget_vendor',
                       charset='utf8')
cursor = conn.cursor()
cursor.execute('SELECT COUNT(*) FROM hc_record')
result = cursor.fetchall()