"""
选择加密方式连接无线
"""
import psutil
import pywifi
import time
from pywifi import const  # 获取连接状态的常量库
import os

##状态码含义
connect_status = {
    0: 'DISCONNECTED',
    1: 'SCANNING',
    2: 'INACTIVE',
    3: 'CONNECTING',
    4: 'CONNECTED',
}


def connect_wireless(ssid, passwd, itf_name, auth="WPA2-PSK"):
    # 抓取网卡接口
    global Realtek_profile
    itf = pywifi.PyWiFi()
    Realtek = itf.interfaces()[0]
    Realtek.disconnect()
    time.sleep(3)
    # 获取wifi的连接状态
    assert Realtek.status() == 0
    print("网卡均已断开无线连接")
    if auth == 'WPA-PSK':
        """
        WPA-PSK
        """
        ##所有连接前的配置信息写入到profile文件内
        profile_wpapsk = pywifi.Profile()
        profile_wpapsk.ssid = ssid
        # 认证方式,OPEN/SHARED
        profile_wpapsk.auth = const.AUTH_ALG_OPEN
        # 加密方式，不支持WPA3-SAE
        profile_wpapsk.akm.append(const.AKM_TYPE_WPA2PSK)
        ##加密规则：CCMP,TKIP,WEP,NONE,UNKNOW
        profile_wpapsk.cipher = const.CIPHER_TYPE_CCMP
        profile_wpapsk.key = "12345678"
        # 添加所有AP配置文件(所连接WiFi的信息)
        Realtek_profile = Realtek.add_network_profile(profile_wpapsk)
    elif auth == 'WPA2-PSK':
        """
        WPA2-PSK
        """
        profile_wpa2psk = pywifi.Profile()
        profile_wpa2psk.ssid = ssid
        profile_wpa2psk.auth = const.AUTH_ALG_OPEN
        profile_wpa2psk.akm.append(const.AKM_TYPE_WPA2PSK)
        profile_wpa2psk.cipher = const.CIPHER_TYPE_CCMP
        profile_wpa2psk.key = passwd
        Realtek_profile = Realtek.add_network_profile(profile_wpa2psk)

    elif auth == 'NONE':
        """
        不加密
        """
        profile_none = pywifi.Profile()
        profile_none.ssid = ssid
        profile_none.auth = const.AUTH_ALG_OPEN
        profile_none.akm.append(const.AKM_TYPE_NONE)
        profile_none.cipher = const.CIPHER_TYPE_NONE
        Realtek_profile = Realtek.add_network_profile(profile_none)
    else:
        raise Exception("请输入正确的加密方式：WPA-PSK、WPA2-PSK、NONE中的一种")
    Realtek.connect(Realtek_profile)
    time.sleep(10)
    for i in range(1, 3):
        if Realtek.status() != 4:
            Realtek.connect(Realtek_profile)
            time.sleep(5)
        else:
            break
    print("无线连接状态：", Realtek.status())
    assert Realtek.status() == 4
    print("Realtek已连接至:{}".format(ssid))
    ipdict = dict()
    dic2 = psutil.net_if_addrs()
    for adapter in dic2:
        sniclist = dic2[adapter]
        for snic in sniclist:
            if '.' in snic.address:
                ipdict[adapter] = snic.address
    wl_ip = ipdict.get(itf_name)
    cmd = 'ping -S {} 1.2.4.8'.format(wl_ip)
    res = os.popen(cmd)
    output = res.read()
    print("无线网卡ping 外网:", output)
    Realtek.disconnect()


if __name__ == '__main__':
    connect_wireless('IP-COM_AA2C18_5G', '12345678', 'W', auth="NONE")
