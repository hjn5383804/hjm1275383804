import re
from configparser import ConfigParser
import os


class ReadElementsIni:
    """只能WEB及其目录下调用"""

    def __init__(self):
        """获取WEB之前的路径与data_config\elements.ini拼接，得到ini路径"""
        self.base_path = re.findall('(.+?WEB)', os.getcwd())[0]
        # 实例读取ini对象
        self.config = ConfigParser()
        ini_path = os.path.join(self.base_path, "data_config\elements.ini")
        with open(ini_path, encoding="utf-8") as fp:
            self.config.read_file(fp)

    # 获取配置文件中元素的值
    def get_ini_elements(self, ini_params):
        """返回属性值"""
        element_value = self.config.get("elements", ini_params)
        return element_value


def get_elements(ini_params):
    """免去每次实例化对象"""
    return ReadElementsIni().get_ini_elements(ini_params)


