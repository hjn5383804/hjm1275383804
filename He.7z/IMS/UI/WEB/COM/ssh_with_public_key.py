#coding=gbk
# ����˽Կ�ַ�����������
import paramiko
from io import StringIO
def ssh_with_public_key(ip,command,file=r'x.pem'):
    with open(file,encoding='utf8',mode='r+') as f:
        key_str=f.read()
    private_key = paramiko.RSAKey(file_obj=StringIO(key_str))
    transport = paramiko.Transport((ip, 22))
    transport.connect(username='root', pkey=private_key)
    ssh = paramiko.SSHClient()
    ssh._transport = transport
    stdin, stdout, stderr = ssh.exec_command(command)
    res, err = stdout.read(), stderr.read()
    result = res if res else err
    print(result.decode())
    # �ر�����
    ssh.close()

ssh_with_public_key('118.31.104.150','df -h')