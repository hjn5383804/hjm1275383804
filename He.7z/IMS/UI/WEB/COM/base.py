import random
from time import sleep
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC, expected_conditions


class Base:
    """不能用于pytest继承，因为含有init方法"""

    def init_browser(self, browser_type, url):
        # 实例化浏览器对象
        if browser_type == "Chrome":
            self.driver = webdriver.Chrome()
        elif browser_type == "Firefox":
            self.driver = webdriver.Firefox()
        elif browser_type == "Ie":
            self.driver = webdriver.Ie()
        elif browser_type == "Edge":
            self.driver = webdriver.Edge()
        elif browser_type == "Opera":
            self.driver = webdriver.Opera()
        else:
            raise NameError('请输入正确的浏览器类型')
        # 打开网址
        self.driver.get(url)
        # 隐式等待
        self.implicitly_wait(15)
        # 窗口最大化
        self.maximize_window()
        # self.full_window()

    def selector_to_locator(self, selector):
        """将如"id,username"的数据，
        拆分为By类定位需要传递的参数：方式、属性值，元组 """
        selector_by = selector.split(",")[0].strip()
        selector_value = selector.split(",")[1].strip()
        if selector_by == "id":
            locator = (By.ID, selector_value)
        elif selector_by == "name":
            locator = (By.NAME, selector_value)
        elif selector_by == "tag_name":
            locator = (By.TAG_NAME, selector_value)
        elif selector_by == "class_name":
            locator = (By.CLASS_NAME, selector_value)
        elif selector_by == "css_selector":
            locator = (By.CSS_SELECTOR, selector_value)
        elif selector_by == "xpath":
            locator = (By.XPATH, selector_value)
        elif selector_by == "link_text":
            locator = (By.LINK_TEXT, selector_value)
        elif selector_by == "partial_link_text":
            locator = (By.PARTIAL_LINK_TEXT, selector_value)
        else:
            raise NameError("请输入正确的定位方式")
        return locator

    def locator_element(self, selector):
        """将获取到的locator，运用在driver对象上，实现元素的操作,解包元组，作为多个参数，传入"""
        locator = self.selector_to_locator(selector)
        return self.driver.find_element(*locator)

    def wait_page_loaded(self, url, timeout=10):
        """等待某个页面加载并返回该url"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        wait.until(expected_conditions.url_contains(url))
        return url

    def wait_element_clickable(self, selector, timeout=10):
        """等待某个元素可以被点击并返回该元素"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        ele = wait.until(expected_conditions.element_to_be_clickable(selector))
        return ele

    def wait_element_visible(self, selector, timeout=10):
        """等待某个元素可见并返回该元素"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        ele = wait.until(expected_conditions.visibility_of_element_located(selector))
        return ele

    def implicitly_wait(self, time):
        """隐式等待"""
        self.driver.implicitly_wait(time)

    def get(self, url):
        """访问url"""
        url = self.wait_page_loaded(url)
        self.driver.get(url)

    def minimize_window(self):
        """最小化窗口（3.0不支持）"""
        self.driver.minimize_window()

    def maximize_window(self):
        """最大化窗口"""
        self.driver.maximize_window()

    def full_window(self):
        """全屏化窗口"""
        self.driver.fullscreen_window()

    def send_keys(self, selector, value):
        """输入值"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.clear()
        ele.send_keys(value)

    def send_file(self, selector, file_path):
        """上传文件"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.send_keys(file_path)

    def click(self, selector):
        """单击"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_clickable(selector)
        ele.click()

    def double_click(self, selector):
        """双击"""
        action = ActionChains(self.driver)
        selector = self.selector_to_locator(selector)
        el = self.wait_element_clickable(selector)
        action.double_click(el).perform()

    def context_click(self, selector):
        """右击"""
        action = ActionChains(self.driver)
        selector = self.selector_to_locator(selector)
        el = self.wait_element_clickable(selector)
        action.context_click(el).perform()

    def move_to_element(self, selector):
        """鼠标悬停在某个元素上"""
        action = ActionChains(self.driver)
        selector = self.selector_to_locator(selector)
        el = self.wait_element_clickable(selector)
        action.move_to_element(el).perform()

    def switch_to_frame(self, selector):
        """进入frame框架"""
        selector=self.selector_to_locator(selector)
        WebDriverWait(self.driver, 10, 1).until(EC.frame_to_be_available_and_switch_to_it(selector))

    def quit_frame(self):
        """退出最外层frame框架"""
        self.driver.switch_to.default_content()


    def quit_last_frame(self):
        """退出上一层的frame框架"""

        self.driver.switch_to.parent_frame()


    def select_by_visible_text(self, selector, text):
        """select框操作-文本"""
        Select(self.locator_element(selector)).select_by_visible_text(text)

    def select_by_index(self, selector, index):
        """select框操作-下标索引"""
        Select(self.locator_element(selector)).select_by_index(index)

    def select_by_value(self, selector, value):
        """select框操作-value值"""
        Select(self.locator_element(selector)).select_by_value(value)

    def sencond_locator(self, selector1, selector2, index):
        """二次定位后点击元素,index从1开始"""
        locator1 = self.selector_to_locator(selector1)
        locator2 = self.selector_to_locator(selector2)
        ele_option = self.driver.find_element(*locator1).find_elements(*locator2)
        ele_option[index].click()

    def get_text(self, selector):
        """获取文本"""
        selector = self.selector_to_locator(selector)
        el = self.wait_element_visible(selector)
        return el.text

    def quit(self):
        """退出浏览器"""
        self.driver.quit()

    def close(self):
        """关闭窗口"""
        self.driver.close()

    def get_screenshot(self, pic_path):
        """获取截图"""
        self.driver.get_screenshot_as_file(pic_path)

    def sleep(self, time):
        """强制等待"""
        sleep(time)

    def quit_iframe(self):
        """退出alert框"""
        self.driver.switch_to.default_content()
        sleep(2)

    def flush(self):
        """刷新页面"""
        self.driver.refresh()

    def alert_accept(self):
        """接受alert框"""
        self.driver.switch_to.alert.accept()

    def alert_dismiss(self):
        """取消alert框"""
        self.driver.switch_to.alert.dismiss()

    def alert_input(self,value):
        """向alert框输入值"""
        self.driver.switch_to.alert.send_keys(value)

    def next_window(self):
        """进入下个窗口"""
        handles = self.driver.window_handles
        self.driver.switch_to.window(handles[0])

    def execute_js(self, js, selector):
        """执行JavaScript"""
        locator = self.selector_to_locator(selector)
        self.driver.execute_script(js, locator)

    def drag_and_drop(self, selector1, selector2):
        """拖动元素到另一元素"""
        action = ActionChains(self.driver)
        selector1 = self.selector_to_locator(selector1)
        selector2 = self.selector_to_locator(selector2)
        el1 = self.wait_element_clickable(selector1)
        el2 = self.wait_element_clickable(selector2)
        action.drag_and_drop(el1, el2).perform()

    def Enter(self):
        """回车"""
        action = ActionChains(self.driver)
        action.send_keys(Keys.ENTER).perform()

    def Ctrl_A(self,selector):
        """ctrl+A"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.send_keys(Keys.CONTROL,"a")

    def Ctrl_C(self,selector):
        """ctrl+C"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.send_keys(Keys.CONTROL, "c")

    def Ctrl_V(self,selector):
        """ctrl+V"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.send_keys(Keys.CONTROL, "v")

    def Ctrl_X(self,selector):
        """ctrl+X"""
        selector = self.selector_to_locator(selector)
        ele = self.wait_element_visible(selector)
        ele.send_keys(Keys.CONTROL, "x")

    def Tab(self):
        """Tab"""
        action = ActionChains(self.driver)
        action.send_keys(Keys.TAB).perform()

    def back(self):
        """后退"""
        self.driver.back()

    def forward(self):
        """前进"""
        self.driver.forward()

    def get_url(self):
        return self.driver.current_url

if __name__ == '__main__':
    d=Base()
    # d.init_browser("Chrome", 'http://www.baidu.com')
    # d.send_keys('id,kw',123)
    d.init_browser('Chrome','http://www.baidu.com')

    # print('id,kw'.split(",")[0].strip())
    # print(d.selector_to_locator('id,kw'))
    # print(d.locator_element('id,p'))
    # d.sleep(5)
    d.quit()
#https://www.cnblogs.com/hongyuz/p/14181097.html