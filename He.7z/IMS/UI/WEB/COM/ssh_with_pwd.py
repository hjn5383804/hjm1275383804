# coding=gbk
import time

import paramiko


def ssh_with_pwd(command, ip, name, pwd):
    s = paramiko.SSHClient()
    s.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # �������Ӳ���know_hosts�ļ��е�����
    s.connect(ip, 22, name, pwd)
    execmd = command
    stdin, stdout, stderr = s.exec_command(execmd)
    data = str(stdout.read(), encoding="utf-8")
    s.close()
    return data



