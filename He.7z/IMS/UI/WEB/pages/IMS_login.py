from UI.WEB.COM.base import Base


from UI.WEB.COM.read_ele_config_ini import get_elements


class IMSLoginPage(Base):

    def ims_login_action(self, username, password):
        self.send_keys(get_elements('账号输入框'), username)
        self.send_keys(get_elements('密码输入框'), password)
        self.click(get_elements('登录按钮'))



    def phonenum_is_null_info(self):
        GET_INFO = self.get_text(get_elements('手机号为空提示'))
        return GET_INFO

    def pwd_is_null_info(self):
        GET_INFO = self.get_text(get_elements('密码为空提示'))
        return GET_INFO

    def invalid_pwd_info(self):
        GET_INFO = self.get_text(get_elements('非法手机号提示'))
        return GET_INFO

    def count_info(self):
        GET_INFO = self.get_text(get_elements('账号提示'))
        return GET_INFO

    def pwd_info(self):
        GET_INFO = self.get_text(get_elements('密码'))
        return GET_INFO

    def quit_action(self):
        self.quit()


# if __name__ == '__main__':
#     login_ims=IMSLoginPage()
#     login_ims.init_browser("Chrome", 'http://118.178.252.225/')
#     login_ims.ims_login_action('18583382064', '123456')