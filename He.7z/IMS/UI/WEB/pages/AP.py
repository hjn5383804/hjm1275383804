from UI.WEB.COM.read_ele_config_ini import get_elements
from UI.WEB.COM.base import Base



class LoginPage(Base):

    def get_error_info_action(self):
        GET_INFO = self.get_text(get_elements('LOGIN_INFO1'))
        return GET_INFO

    def get_null_info_action(self):
        GET_INFO = self.get_text(get_elements('LOGIN_INFO2'))
        return GET_INFO

    def quit_action(self):
        self.quit()

    def login_action(self, username, password):
        self.send_keys(get_elements('NAME'), username)
        self.send_keys(get_elements('PASSWORD'), password)
        self.click(get_elements('LOGIN'))


class ResetPage(LoginPage):
    def reset_action(self):
        self.login_action('admin', 'admin')
        self.click(get_elements('SYS_TOOLS'))
        self.click(get_elements('DEV_MAINTAIN'))
        self.click(get_elements('RESET'))
        self.click(get_elements('OK'))

    def get_reset_info(self):
        GET_INFO = self.get_text(get_elements('RESET_INFO'))
        return GET_INFO

    def quit_reset_action(self):
        self.sleep(90)
        self.quit()
if __name__ == '__main__':
    login=LoginPage()
    login.init_browser("Chrome", 'http://192.168.3.190')
    login.login_action('admin', 'admin')