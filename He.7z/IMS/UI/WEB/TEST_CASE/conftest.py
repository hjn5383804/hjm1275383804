import csv
# pytest --reruns 2 --reruns-delay 5 -s
import allure
import pytest
import yaml

# from IMS.UI.WEB.pages.W83AP import LoginPage


# 1、每个接口需共用到的token
# 2、每个接口需共用到的测试用例数据
# 3、每个接口需共用到的配置信息
#
# @pytest.fixture(scope="session", autouse=True)
# def env(request):
#     """
#     Parse env config info
#     pass
