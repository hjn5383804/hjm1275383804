import pytest

from UI.WEB.COM.get_file_data import GetFileData
from UI.WEB.COM.read_path_ini import ReadPathIni
from UI.WEB.pages.AP import LoginPage



login = LoginPage()

class TestLogin(LoginPage):
    login = LoginPage()
    @classmethod
    def setup_class(cls):
        login.init_browser("Chrome", 'http://192.168.3.190')

    @classmethod
    def teardown_class(cls):
        login.quit()

    @pytest.mark.parametrize("desc, username, password, exp",
                             GetFileData().get_csv(ReadPathIni().get_csv_path('test.csv')))
    def test_login(self, desc, username, password, exp):
        """登录失败"""
        login.login_action(username, password)
        if username == "" or password == "" or username == password == "":
            text = login.get_null_info_action()
        else:
            text = login.get_error_info_action()
        assert exp == text
        print("获取页面提示文本与预期一致")
