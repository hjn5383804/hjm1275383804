

import pytest

from UI.WEB.pages.AP import LoginPage


login = LoginPage()


class TestLogin(LoginPage):

    # @pytest.mark.usefixtures("init_browser")
    # def test_1(self):
    #     print("test_1")

    @pytest.mark.parametrize("x",[1,2])
    @pytest.mark.parametrize("y",[8,10,11])
    def test_foo(self,x,y):
        print(f"测试数据组合x: {x} , y:{y}")