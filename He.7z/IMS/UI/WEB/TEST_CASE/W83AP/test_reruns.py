import pytest
import datetime

@pytest.mark.flaky(reruns=2, reruns_delay=5)
def test_case1():
    print("执行测试用例1")
    print(datetime.datetime.now())
    assert 1 + 1 == 3


@pytest.mark.flaky(reruns=2, reruns_delay=5)
def test_case2():
    print("执行测试用例2")
    print(datetime.datetime.now())
    assert 1 + 3 == 6


def test_case3():
    print("执行测试用例3")
    assert 1 + 3 == 4

if __name__ == '__main__':
    pytest.main()