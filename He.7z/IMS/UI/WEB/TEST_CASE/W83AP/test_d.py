# import pytest
#
#
# @pytest.fixture(params=[1, 2, 3, 5])
# def data(request):
#     return request.param
#
# def test_not_2(data):
#     print(f"测试数据={data}")
#     assert data < 5
#
#
#
#
# #当测试数据需要同时在固件和用例中使用时
#
# @pytest.fixture(scope="module")
# def login_r(request):
#     # 通过request.param获取参数
#     user = request.param
#     print(f"\n 登录用户：{user}")
#     return user
#
#
# @pytest.mark.parametrize("login_r", ['Tome', 'Jerry'], indirect=True)
# def test_login(login_r):
#     A = login_r
#     print(f"测试用例中login的返回值; {A}")
#     assert A != ""

a=""
if a:
    print(1)