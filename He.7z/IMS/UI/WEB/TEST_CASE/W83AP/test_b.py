import pytest


class TestPytest(object):

    # @pytest.mark.run(order=2)
    # def test_two(self):
    #     print("test_two，测试用例")
    #
    # @pytest.mark.run(order=3)
    # def test_one(self):
    #     print("test_one，测试用例")
    #
    # @pytest.mark.run(order=1)
    # def test_three(self):
    #     print("\ntest_three，测试用例")

    @pytest.mark.parametrize("test_input,expected", [["3+5", 8], ["2+5", 7], ["7*5", 35]])
    def test_eval(self, test_input, expected):
        # eval 将字符串str当成有效的表达式来求值，并返回结果
        assert eval(test_input) == expected
