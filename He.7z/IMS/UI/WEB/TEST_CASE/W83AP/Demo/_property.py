class C(object):
    def __init__(self):
        self._x = None
    @property
    def x(self):
        """用于获取x"""
        return self._x
    @x.setter
    def x(self, value):
        """用于修改x"""
        self._x = value
    @x.deleter
    def x(self):
        """用于删除x"""
        del self._x

X=C()
print(X.x)
X.x=1024
print(X.x)
del X.x
print(X.x)