import pytest


@pytest.fixture()
def init():
    print("初始化环境1")
    return 1


@pytest.fixture(autouse=True)
def init_2():
    print('初始化环境2')


# 方法一：
def test_1(init):
    print('test_1')


# 方法二：
@pytest.mark.usefixtures('init')
def test_2():
    print('test_2')


# 方法三：
def test_3():
    print('test_3')
