import pytest
import allure
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@pytest.fixture(scope="session")  # 用例前置操作
def login_fixture():
    # 比如登录获取token操作
    return "token:xx"


@allure.step("用例步骤1")
def step_1():
    logger.info("用例操作---------------步骤1")
    return True


@allure.step("用例步骤2")
def step_2():
    logger.info("用例操作---------------步骤2")
    return False


@allure.step("用例步骤3")
def step_3():
    logger.info("用例操作---------------步骤3")
    return True


@allure.epic("可以对用例或用例集进行描述分类（若出现多个时，内容一致则自动归为一类）")
@allure.feature("对用例集或用例进行描述分类---与epic类似，只是比epic级别低")
@allure.story("对用例集或用例进行描述分类---与epic类似，只是比feature级别低")
class TestAllureDemo:

    @allure.testcase("https://xxx/testcase/list",
                     name='用例链接testcase')  # 为了更好的链接到问题分类或者bug、测试用例地址中（url、name两个参数，可不填写name；可以用@allure.link）
    @allure.link("https://xxx/testcase/list", name='用例链接link')  # 与testcase没有多大区别，从可读性角度还是建议选择@allure.link
    @allure.issue("https://xxx/testcase/list", name='用例链接issue')  # 与testcase区别在于有小虫子图标
    @allure.title("用例的标题")  # 可参数化标题
    @allure.story("用例分类：1")  # 可参数化标题
    @allure.severity("critical")  # 用例等级（blocker critical normal minor trivial）
    def test_case_1(self, login_fixture):
        """
        1.用例描述
        2.用例步骤
        3.预期结果
        """
        logger.info(login_fixture)  # 获取用例前置的信息，比如登录token
        assert step_1()
        assert step_2()

    @allure.story("用例分类：2")
    def test_case_2(self, login_fixture):
        logger.info("测试用例2")
        assert step_1()
        assert step_3()


@allure.epic("冒烟自动化用例")
class TestDemo2:

    @allure.story("用例分类：3")
    def test_case_3(self, login_fixture):
        logger.info("测试用例3")
        step_1()

    @allure.story("用例分类：4")
    def test_case_4(self, login_fixture):
        logger.info("测试用例4")
        step_3()
