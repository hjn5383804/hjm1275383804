import unittest
from UI.WEB.COM.get_file_data import GetFileData
from ddt import ddt, data, unpack, file_data




@ddt
class TestDemo(unittest.TestCase):

        @data([1, 2, 3])
        def test_1_1(self, value):
            """一个列表代表一条用例，只有一个参数，参数是整个列表"""
            print(value)

        @data([1, 2, 3])
        @unpack
        def test_1_2(self, a, b, c):
            """一个列表代表一条用例，有3个参数，参数是a、b、c"""
            print(a, b, c)

        @data(1, 2, 3)
        def test_2(self, value):
            """一个数据代表一条用例，只有一个参数，参数是1、2、3中的一个"""
            print(value)

        @data([3, 2, 1], [5, 3, 2], [10, 4, 6])
        @unpack
        def test_minus(self, a, b, expected):
            """一个列表代表一条用例，有3个参数，参数是每个列表解包后的三个数据"""
            actual = int(a) - int(b)
            expected = int(expected)
            self.assertEqual(actual, expected)

        @data(*[[3, 3], [4, 4]])
        @unpack
        def test_compare(self, a, b):
            """*与unpack并不冲突，可搭配使用，列表或元组嵌套时，先使用*再使用unpack"""
            self.assertEqual(a, b)

        @data(*GetFileData().get_csv(r'E://A.csv'))
        @unpack
        def test_data_csv(self, student_id, name, grade, desc):
            """调用方法返回嵌套类型的数据时，同上"""
            print(student_id, name, grade, desc)

        @file_data('test.json')
        def test_json(self, name,passwd,content):
            """传文件路径,使用file_data，应用json文件中的内容，与def函数中的参数个数对应"""
            print(name,passwd,content)

        @file_data('test2.json')
        def test_json2(self, token,actionName,content):
            """传文件路径,使用file_data，应用json文件中的内容，与def函数中的参数个数和名称对应"""
            print(token,actionName,content)

        @file_data('test.yaml')
        def test_yaml(self, data):
            """遍历字典获取"""
            for i in data:
                url = i.get('url')
                key = i.get('key')
                content = i.get('content')
                print("url:", url, "key:", key, "content:", content)


if __name__ == '__main__':
    unittest.main()
