import pytest

#
# @pytest.mark.parametrize("test_input,expected", [(10, 8), (5, 7), (1, 30)])
# def test_params_to_testcase(test_input, expected):
#     assert test_input > expected
#
#
# @pytest.mark.parametrize("username", ["空", "不足长度字符", "超长字符", "非法字符"])
# @pytest.mark.parametrize("passwd", ["1", "123456", ""])
# def test_foo(username, passwd):
#     """测试中通常使用这种方法是所有变量、所有取值的完全组合，可以实现全面的测试。"""
#     print(username)
#     print(passwd)


# # 方法名作为参数
# test_user_data = [['admin', '123456'],["root","000000"]]
#
#
# @pytest.fixture(scope="module")
# def login_request(request):
#     # 通过request.param获取参数
#     user = request.param
#     print(user)
#     return user
#
#
# @pytest.mark.parametrize("user_name,passwd", test_user_data, indirect=True)
# def test_login(login_request,user_name,passwd):
#     print(user_name)
#     print(passwd)


# 方法名作为参数
test_user_data = [['admin', '123456'], ["root", "000000"]]


@pytest.fixture(scope="module")
def login(request):
    # 通过request.param获取参数
    print("固件执行", request.param)
    return request.param


@pytest.mark.parametrize("login", test_user_data, indirect=True)
def test_login(login):
    print("用例执行", login)



# direct 参数设置为 True，pytest 会把 argnames 当作函数去执行，将 argvalues 作为参数传入到 argnames 这个函数里

if __name__ == '__main__':
    pytest.main()
