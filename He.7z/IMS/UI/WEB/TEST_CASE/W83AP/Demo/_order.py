import pytest

class TestPytest(object):

    @pytest.mark.run(order=3)
    def test_1(self):
        print("test_1，测试用例")

    @pytest.mark.run(order=2)
    def test_2(self):
        print("test_2，测试用例")


    @pytest.mark.run(order=1)
    def test_3(self):
        print("\ntest_3，测试用例")

if __name__ == '__main__':
    pytest.main()

# pytest IMS\UI\WEB\TEST_CASE\W83AP\Demo\_order.py -s
#2 3 1