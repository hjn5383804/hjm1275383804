import pytest


@pytest.fixture()
def init():
    print("初始化环境1")
    return 1


@pytest.fixture()
def init2():
    print("初始化环境2")


def test_case1(init, init2):
    print(init)
    print(init2)
    print("执行test_case1")


def test_case2():
    print("执行test_case2 ")


def test_case3(init):
    print(init)
    print("执行test_case3")
