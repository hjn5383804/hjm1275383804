def setup_module():
    print("\nsetup_module，只执行一次，当有多个测试类的时候使用")


def teardown_module():
    print("\nteardown_module，只执行一次，当有多个测试类的时候使用")


class TestPytest1(object):

    @classmethod
    def setup_class(cls):
        print("\nsetup_class1，只执行一次")

    @classmethod
    def teardown_class(cls):
        print("\nteardown_class1，只执行一次")

    def setup_method(self):
        print("\nsetup_method1，每个测试方法都执行一次")

    def teardown_method(self):
        print("teardown_method1，每个测试方法都执行一次")

    def test_3(self):
        print("test_3，测试用例")

    def test_4(self):
        print("test_4，测试用例")


class TestPytest2(object):

    @classmethod
    def setup_class(cls):
        print("\nsetup_class2，只执行一次")

    @classmethod
    def teardown_class(cls):
        print("\nteardown_class2，只执行一次")

    def setup_method(self):
        print("\nsetup_method2，每个测试方法都执行一次")

    def teardown_method(self):
        print("teardown_method2，每个测试方法都执行一次")

    def test_2(self):
        print("test_2，测试用例")

    def test_1(self):
        print("test_1，测试用例")
