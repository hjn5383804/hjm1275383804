#!/usr/bin/env python
# -*- coding: utf-8 -*-
import allure
import pytest
from UI.WEB.COM.read_path_ini import ReadPathIni

from UI.WEB.COM.get_file_data import GetFileData
from UI.WEB.pages.IMS_login import IMSLoginPage
page = IMSLoginPage()
@pytest.fixture(scope='function', autouse=True)
def close():
    page.init_browser("Chrome", 'http://118.178.252.225/')
    yield  # 之后的都是后置
    page.quit()



@allure.story("登录异常场景用例集")
class TestAllureDemo:
    @allure.title("登录失败测试用例-{case_desc}")  # 可参数化标题
    @allure.testcase("http://www.github.com")
    @allure.feature("账号密码登录模块")
    @allure.severity("critical")
    @allure.story("用例分类：1")
    @pytest.mark.parametrize('case_desc,username,passwd,exp1,exp2',
                             GetFileData().get_csv(ReadPathIni().get_csv_path('ims_login.csv')))
    def test_steps_demo(self, case_desc, username, passwd, exp1, exp2):

        with allure.step(f"输入用户名、密码并点击登录：{username}{passwd}"):
            page.ims_login_action(username, passwd)

        with allure.step(f"获取账号提示并断言：{exp1}"):
            if exp1 != "":
                assert page.count_info() == exp1

        with allure.step(f"获取密码提示并断言：{exp2}"):
            if exp2 != "":
                assert page.pwd_info() == exp2


if __name__ == '__main__':
    pytest.main()
