import logging
import sys
def get_log(path):
    ###实例化对象
    log=logging.Logger("pro_ranzhi21")
    ###设置日志格式
    log_format=logging.Formatter('[%(asctime)s][%(filename)s][%(levelname)s]:%(message)s')
    ##实例化FileHandler,保存日志到指定位置
    file_handler=logging.FileHandler(path,encoding="utf8")
    ###引用格式添加到文件
    file_handler.setFormatter(log_format)
    ###把文件添加到日志对象
    log.addHandler(file_handler)

    #打印日志到控制台
    kzt=logging.StreamHandler(sys.stdout)

    kzt.setFormatter(log_format)
    ###把日志添加到对象
    log.addHandler(kzt)
    return log