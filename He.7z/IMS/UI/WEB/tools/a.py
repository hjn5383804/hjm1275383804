import sys
import glob
import time

import serial


def serial_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            B list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[B-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result


"""
port: 串口号，str格式，例如‘COM3’；

baudrate: 波特率，str格式，例如‘9600’；

parity:校验位，str格式。只需要第一个字母，‘N’无校验，‘O’奇校验，‘E’偶校验；

value: 设置的数据，数据需要为int格式，多字节传输采用list。
"""
serial = serial.Serial()

serial.bytesize = 8
serial.parity = 'N'
serial.stopbits = 1
serial.timeout = 2
serial.write_timeout = 2
serial.baudrate = '115200'
serial.port = 'COM4'
serial.open()
serial.write('Fireitup'.encode() + '\n'.encode())
# 发送ctrl+C
serial.write(chr(0x03).encode())
serial.write('reboot'.encode() + '\n'.encode())
# 发送ctrl+C
serial.write(chr(0x03).encode())
# 以行读取
print(serial.readline())
# 单个读取
str_len = serial.inWaiting()
if str_len:
    serial.read(str_len)

serial.close()
