import pywifi
import time
##状态码含义
connect_status = {
    0: 'DISCONNECTED',
    1: 'SCANNING',
    2: 'INACTIVE',
    3: 'CONNECTING',
    4: 'CONNECTED',
}
def scan_ssid():
# 抓取网卡接口
    itf = pywifi.PyWiFi()
    Realtek = itf.interfaces()[0]
    while True:
        try:
            ##开始扫描周围ssid
            Realtek.scan()
            time.sleep(5)
            # 扫描结束，输出结果
            result=Realtek.scan_results()
            ssid=[]
            mac=[]
            for i in result:
                ssid.append(i.ssid.encode('raw_unicode_escape').decode("utf8"))
                mac.append(i.bssid.encode('raw_unicode_escape').decode("utf8"))
            x=set(ssid)
            y=set(mac)
            return x,y
        except:
            print("本次扫描打印失败，准备重新扫描......")
            flag=1
        if flag!=1:
            break
print(scan_ssid())