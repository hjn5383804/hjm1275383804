# netsh wlan show networks mode=bssid
import ctypes, sys, re, os
import datetime
import subprocess
import time
import traceback
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False
def scan_ssid(ssid) :
    if is_admin():
        print("已经以管理员权限运行")
        with open('D://logfile.txt', 'w') as f1:
            subprocess.run('netsh wlan show networks mode=bssid', stdout=f1,
                           universal_newlines=True)
            f1.close()
        with open('D://logfile.txt', 'r', errors='ignore') as f2:
            data=f2.read()
            data=data.replace('\n',"").replace(" ","")
            # print(data)
            assert ssid in data
            result=re.findall(r':{}.+?本'.format(ssid),data)
            # print(Result)
            for i in result:
                print(len(result))
                SSID=re.findall(':(.+?)Networktype',i)[0]
                if SSID!=ssid:
                    break
                else:
                    result = i
                    # print(SSID)
                    print("无线网卡成功扫描到SSID："+SSID)
                    nettype=re.findall('Networktype:(.+?)身份验证',result)[0]
                    print("网络类型："+nettype)

                    auth=re.findall('身份验证:(.+?)加密',result)[0]
                    print("身份验证："+auth)

                    pwd=re.findall('加密:(.+?)BSSID',result)[0]
                    print("加密方式："+pwd)

                    BSSID=re.findall('BSSID1:(.+?)信号',result)[0]
                    print("BSSID："+BSSID)

                    sn=re.findall('信号:(.+?)无线电类型',result)[0]
                    print("信号："+sn)

                    wltype=re.findall('无线电类型:(.+?)频道',result)[0]
                    print("无线电类型："+wltype)

                    channel=re.findall('频道:(.+?)基',result)[0]
                    print("信道："+channel)

                    f2.close()
                    # os.remove('D://logfile.txt')
                    return True
    else:
        if sys.version_info[0] == 3:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, __file__, None, 1)
if __name__ == '__main__':
        try:
            scan_ssid('TEST623')
        except Exception as e:
            print("扫描失败，异常类型为："+repr(e))
            print(traceback.format_exc())
        print(str(datetime.datetime.now())[0:19])
