
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def send_email1(report_path):
    # try:
        # 配置服务器信息
        # 配置服务器
        smtp = "smtp.163.com"
        # 配置端口
        port = "25"
        # 配置登录用户
        sender = "aa18583382064@163.com"
        # 配置密码，注意：这个密码是邮箱的授权码，不是邮箱的登录密码
        pwd = "FVEUFDISFLFUJMKF"
        # 配置接收用户
        receiver = "aa18583382064@163.com,1275383804@qq.com"

        # 创建邮件对象
        msg = MIMEMultipart()
        msg["from"] = sender
        msg["to"] = receiver
        msg["subject"] = "然之测试报告"

        # 读取报告内容
        with open(report_path,mode="rb") as report:
            body = report.read()
        # 正文
        text = MIMEText(body,"html","utf8")
        msg.attach(text)

        # 添加附件
        fujian= MIMEText(body,"base64","utf8")
        # 添加附件
        fujian['Content-Type'] = 'application/octet-stream'
        fujian["Content-Disposition"] = "attachment;filename = %s" % report_path
        msg.attach(fujian)

        # 发送邮件
        smtp1 = smtplib.SMTP()
        # 连接服务器
        smtp1.connect(smtp,port)
        # 登录
        smtp1.login(sender,pwd)
        # 发送
        smtp1.sendmail(sender,receiver.split(","),msg.as_string())
        print("发送成功")
    # except:
    #     print("发送失败")
