import pyautogui

print(pyautogui.size())
# pyautogui.displayMousePosition()

pyautogui.moveTo(382, 520,duration=0.25)
pyautogui.doubleClick(382, 520)
