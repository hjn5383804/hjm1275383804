import os
import pytest

pytest.main(['-s', '-q', r'F:\WEB\Demo\test_allure.py', '--alluredir', r'F:\WEB\allure_temp'])
os.system("allure generate F:\\WEB\\allure_temp -o F:\\WEB\\result\\report --clean")