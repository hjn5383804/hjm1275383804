import uiautomator2 as u2
import os
from time import sleep
import pytest
import logging
import openpyxl
# coding=utf8
# DEVICE_IP = "192.168.0.183"
APP_PACKAGE = "com.tenda.router.app"
BOOK_NAME = "user_data.xlsx"
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(funcName)s - %(message)s')
logger = logging.getLogger(__name__)
d = u2.connect_usb()  # �����ֻ�devices���к�

def run_app():
    d.app_stop(APP_PACKAGE)
    d.app_start(APP_PACKAGE)  # �򿪳���
    if d.session(APP_PACKAGE, attach=True):  # �жϳ����Ƿ��
        logger.info("�Ѵ򿪳���")
        sleep(5)
        # �״ν����¼ҳ��
        if d(text="��¼һ��").exists:
            d(resourceId="com.tenda.router.app:id/iv_close").click()
            logger.info("�رյ�¼����ʾ")
        d(resourceId="com.tenda.router.app:id/id_menu").click()
        if d(resourceId="com.tenda.router.app:id/tv_logout").exists:
            print("�˺��ѵ�¼���ֵǳ��˺�")
            d(resourceId="com.tenda.router.app:id/tv_logout").click()
            d(resourceId="com.tenda.router.app:id/reset_router_tv_confirm").click()
        d(resourceId="com.tenda.router.app:id/tv_login").click()
        logger.info("�����¼ҳ��")

def readData(BOOK_NAME):
    data_list = []
    book = openpyxl.load_workbook(BOOK_NAME)
    sheet = book.active
    min_row = sheet.min_row
    max_row = sheet.max_row
    min_column = sheet.min_column
    max_column = sheet.max_column
    for row in sheet.iter_rows(min_row=min_row+1, min_col=min_column, max_row=max_row, max_col=max_column):
        row_tuple = ((row[0].value,row[1].value),row[2].value)
        data_list.append(row_tuple)
    return data_list

data_list = readData(BOOK_NAME)
run_app()
@pytest.mark.parametrize("test_input,expected", data_list)
def test_loginApp(test_input,expected):
    account = test_input[0]
    password = test_input[1]
    #��¼�ɹ����˳���¼
    if d(resourceId="com.tenda.router.app:id/tv_logout").exists:
        print("�˺��ѵ�¼���ֵǳ��˺�")
        d(resourceId="com.tenda.router.app:id/tv_logout").click()
        d(resourceId="com.tenda.router.app:id/reset_router_tv_confirm").click()
        d(resourceId="com.tenda.router.app:id/tv_login").click()
        logger.info("�ٴν����¼ҳ��")
    # if d(resourceId="com.tenda.router.app:id/tv_login").exists:
    print("��¼Ԫ�ش���")
    d(resourceId="com.tenda.router.app:id/cloud_account_login_et_username").set_text(account)
    logger.info("�˺�������")
    d(resourceId="com.android.systemui:id/back").click()
    d(resourceId="com.tenda.router.app:id/cloud_account_login_et_password").send_keys(password)
    d(resourceId="com.android.systemui:id/back").click()
    logger.info("����������")
    logger.info("��ʼ��¼")
    try:
        d(resourceId="com.tenda.router.app:id/cloud_account_login_btn_login").click(timeout=10)  # ��¼��ʱ��ȴ�10��
    except Exception as e:
        print(e)
    sleep(2)
    assert (d(resourceId="com.tenda.router.app:id/tv_account_name").exists() == True and expected == 1)



if __name__ == '__main__':

    pytest.main(['-s', '-q', 'test_pytest.py', '--alluredir', 'F:/python_code/PyCharm/Raw_Files'])
    os.system("allure generate Raw_Files -o Report --clean")




