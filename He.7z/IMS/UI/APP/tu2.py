import uiautomator2 as u2
import time
serial='CUY0219604009498'
d = u2.connect_usb(serial)
d.set_new_command_timeout(300)
# d.app_start('com.ipcom.imsen')
d(text="飞书").click()
time.sleep(10)
d.xpath('//*[@resource-id="com.ss.android.lark:id/rv_inbox"]/android.widget.FrameLayout[4]').click()

d(resourceId="com.ss.android.lark:id/normal_message_et_layout").click()

d.send_keys("smoking", clear=True)
d.click(0.925, 0.861)