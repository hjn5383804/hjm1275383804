from pywinauto.application import Application
import time
from UI.PC.pc_auto import PC
# 启动微信客户端
action=PC()
app = Application().start(r'D:\IXC\IxChariot.exe')
time.sleep(3)
# 连接主窗口
dlg = app.window(title="IxChariot Test - untitled1.tst", class_name="WindowsForms10.Window.8.app3")
if dlg.exists():
   print(1)

# 等待加载
time.sleep(1)

#新建流
action.ctrl_customized('p')
action.copy_text('192.168.1.204')
action.ctrl_V()
action.Tab()
action.copy_text('192.168.1.217')
action.ctrl_V()
#UDP
action.Tab()
for i in range(2):
    action.down()
for i in range(2):
    action.Tab()

action.space()
time.sleep(1)
#跑流脚本
action.copy_text('Throughput.scr')
action.ctrl_V()
action.enter()
action.enter()
#复制流
action.ctrl_A()
action.ctrl_C()
for i in range(10):
    action.ctrl_V()
#运行
action.ctrl_customized('r')
# time.sleep(10)
# app.kill()


