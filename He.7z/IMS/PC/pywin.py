import time
#   常用的检查工具：
#   1. Inspect（定位元素工具（uia））
#   2. Spy++ （定位元素工具（win32））
from pywinauto.application import Application

from PC.pc_auto import PC


import datetime

app = Application(backend="uia").start("notepad.exe")
time.sleep(3)
main=app.window(class_neme='Notepad')
main.maximize()


app.kill()


































































































# pc_auto=PC()
# for i in range(10):
#     time = str(datetime.datetime.now())
#     pc_auto.copy_text(time)
#     pc_auto.ctrl_L()
#     pc_auto.ctrl_V()
#     pc_auto.enter()
# pc_auto.ctrl_S()
#
# pc_auto.copy_text(r'test_pc_auto2.txt')
# pc_auto.ctrl_V()
# pc_auto.enter()
# pc_auto.alt_f4()

#TUEyNjEwMTEwMTNIMDAwMDE5
#cfm set ims.d2023-03-30 09:58:25ebug.ip 120.27.208.184
#sk-fiMVOhARk7LhKOM2023-03-30 09:58:36LrMf2T3BlbkFJXgTqrs0ub2R9dSvDuLln