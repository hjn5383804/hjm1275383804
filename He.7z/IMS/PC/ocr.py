from PIL import Image
import pytesseract


pytesseract.pytesseract.tesseract_cmd = r'F:\orc\Tesseract-OCR\tesseract.exe'

# 加载图像
image = Image.open('test.jpg')
# 列出支持的语言
print(pytesseract.get_languages(config=''))
text = pytesseract.image_to_string(image, lang='chi_sim')
print(text)
