import random
import time

import pyperclip
from pynput.keyboard import Key, Controller as kc
from pynput.mouse import Controller as mc
from pynput.mouse import Listener, Button
import win32api
import win32con


def on_move(x, y):
    #开启鼠标监听后的动作
    print("当前鼠标位置：{0}".format((x, y)))
    return (x,y)



class PC():

    def __init__(self, x=0, y=0):
        """1.初始化鼠标位置，默认为原处;
           2.初始化键盘控制对象;
        """
        win32api.mouse_event(
            win32con.MOUSEEVENTF_LEFTDOWN |
            win32con.MOUSEEVENTF_LEFTUP, x, y)
        self.mouse = mc()
        self.keyboard = kc()

    def get_mouse_position(self):
        # 获取当前鼠标坐标
        x, y = self.mouse.position
        return (x, y)

    def move_mouse_to(self, position):
        # 移动鼠标到指定坐标
        self.mouse.position = position

    def copy_text(self, text):
        """复制文字到电脑剪切板，供粘贴使用"""
        pyperclip.copy(text)
        return pyperclip.paste()

    def ctrl_A(self):
        """全选"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('a')
            self.keyboard.release('a')
        time.sleep(0.5)

    def ctrl_X(self):
        """剪切"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('x')
            self.keyboard.release('x')
        time.sleep(0.5)

    def ctrl_C(self):
        """复制"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('c')
            self.keyboard.release('c')
        time.sleep(0.5)

    def ctrl_V(self):
        """粘贴"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('v')
            self.keyboard.release('v')
        time.sleep(0.5)

    def ctrl_L(self):
        """去除输入光标"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('l')
            self.keyboard.release('l')
        time.sleep(0.5)
    def ctrl_S(self):
        """去除输入光标"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('s')
            self.keyboard.release('s')
        time.sleep(0.5)
    def ctrl_R(self):
        """去除输入光标"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press('r')
            self.keyboard.release('r')
        time.sleep(0.5)

    def left_click(self):
        # 单次左击
        self.mouse.press(Button.left)
        self.mouse.release(Button.left)

    def right_click(self):
        # 单次右击
        self.mouse.press(Button.right)
        self.mouse.release(Button.right)

    def multi_left_click(self, num):
        # 多次左击
        self.mouse.click(Button.left, num)

    def multi_right_click(self, num):
        # 多次右击
        self.mouse.click(Button.right, num)

    def mouseListener(self):
        #动获取鼠标坐标
        with Listener(on_move=on_move) as listener:
            listener.join()

    """"alt,alt.1,alt_r,backspace,caps_lock,emd,emd_r,ctrl,ctrl_1,ctrl_r,delete,down,end,‘enter,esc,f1-f20,home,insert,
    left,menu,num_lock,,page_down,page_up,pause,print_screen,right,scroll_lock,shift,shift_r,space,tab,up """

    def down(self):
        self.keyboard.press(Key.down)
        self.keyboard.release(Key.down)
        time.sleep(0.5)

    def up(self):
        self.keyboard.press(Key.up)
        self.keyboard.release(Key.up)
        time.sleep(0.5)

    def left(self):
        self.keyboard.press(Key.left)
        self.keyboard.release(Key.left)
        time.sleep(0.5)

    def right(self):
        self.keyboard.press(Key.right)
        self.keyboard.release(Key.right)
        time.sleep(0.5)

    def enter(self):
        # 回车
        self.keyboard.press(Key.enter)
        self.keyboard.release(Key.enter)
        time.sleep(0.5)

    def space(self):
        # 空格
        self.keyboard.press(Key.space)
        self.keyboard.release(Key.space)
        time.sleep(0.5)

    def backspace(self):
        # 后退删除
        self.keyboard.press(Key.space)
        self.keyboard.release(Key.space)
        time.sleep(0.5)

    def delete(self):
        # 前进删除
        self.keyboard.press(Key.delete)
        self.keyboard.release(Key.delete)
        time.sleep(0.5)

    def win(self):
        # cmd
        self.keyboard.press(Key.cmd)
        self.keyboard.release(Key.cmd)
        time.sleep(0.5)
    def win_r(self):
        # cmd_r
        self.keyboard.press(Key.cmd_r)
        self.keyboard.release(Key.cmd_r)
        time.sleep(0.5)
    def alt_tab(self):
        # 切换界面
        with self.keyboard.pressed(Key.alt):
            self.keyboard.press(Key.tab)
            self.keyboard.release(Key.tab)

    def print_screen(self):
        #截屏
        self.keyboard.press(Key.print_screen)
        self.keyboard.release(Key.print_screen)
        time.sleep(0.5)

    def alt_f4(self):
        # 切换界面
        with self.keyboard.pressed(Key.alt):
            self.keyboard.press(Key.f4)
            self.keyboard.release(Key.f4)

    def send_keys(self,keys):
        #从键盘输入字符串
        self.keyboard.type(keys)
    def send_touch(self,keys):
        #从键盘输入特殊符号
        self.keyboard.touch(keys,True)

    def ctrl_customized(self,value):
        """去除输入光标"""
        with self.keyboard.pressed(Key.ctrl):
            self.keyboard.press(value)
            self.keyboard.release(value)
        time.sleep(0.5)

    def Tab(self):
        # 空格
        self.keyboard.press(Key.tab)
        self.keyboard.release(Key.tab)
        time.sleep(0.5)

    def drog(self):
        image_position = [(1489, 658), (1592, 642), (1522, 658), (1613, 657),(1590,673)]
        for i in image_position:
            self.move_mouse_to((1414,663))
            time.sleep(1)
            self.mouse.press(Button.left)
            time.sleep(1)
            self.move_mouse_to(i)
            time.sleep(1)
            self.mouse.release(Button.left)
            time.sleep(3)
if __name__ == '__main__':

    x=PC()
    while 1:
        print(x.get_mouse_position())
        time.sleep(1)



    #
    # time.sleep(5)
    # x.drog()








    # time.sleep(3)
    # while 1:
    #
    #     x = PC()
    #     x.move_mouse_to((1714,373))
    #     x.left_click()
    #     time.sleep(1)
    #     x.move_mouse_to((1447, 487))
    #     x.left_click()
    #     time.sleep(1)
    #     x.copy_text('盘点任务责任人导入模板 (16).xls')
    #     x.ctrl_V()
    #     x.enter()
    #     time.sleep(5)
    #     x.ctrl_R()
    #     time.sleep(3)
    #
    # time.sleep(5)
    # while 1:
    #     x = PC()
    #     x.left_click()
    #     time.sleep(1)