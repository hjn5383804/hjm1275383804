from pywinauto.application import Application

from PC.pc_auto import PC

import datetime
import time
action=PC()
#1.连接已启动的程序
app=Application().connect(path=r'D:\Download\WX\WeChat\WeChat.exe')

#2.定位微信的主窗口

main_win=app.window(title='微信',control_type='窗口',class_name='WeChatMainWndForPC')
main_win.print_control_identifiers(depth=None,filename='weixin.txt')
# main_win.maximize()
# #3.定位主窗口下的某个窗口

time.sleep(5)
#联系人
# selectItem = main_win.child_window(title='搜
# 索', control_type="编辑").wrapper_object()
# selectItem.draw_outline(colour='red')
# selectItem.click_input()
#

#
# inputMsg = main_win.child_window(title="输入", control_type="Edit").wrapper_object()
# inputMsg.click_input()
# inputMsg.type_keys('sendMsg', with_spaces=True)

action.enter()