#选择菜单项
# 微信主界面几种方式：
# 这个最好用
import time

from PC.pc_auto import PC

from pywinauto.application import Application
# PC_method=PC()
#
# app = Application(backend="uia").start('notepad.exe')
#
# main_Win = app.window(class_name='Notepad')
#
# main_Win.print_control_identifiers(depth=None,filename='a.txt')
#
# app.kill()



app2 = Application(backend="win32").start(r'D:\Download\WX\WeChat\WeChat.exe')
main_Win2 = app2.window(class_name='WeChatMainWndForPC')
main_Win2.print_control_identifiers(depth=None,filename='1.txt')
app2.kill()