import psutil


def get_process_id_by_name(name):
    PID = 0
    for proc in psutil.process_iter():
        try:
            pinfo = proc.as_dict(attrs=['pid', 'name'])
        except psutil.NoSuchProcess:
            pass
        else:
            if name == pinfo['name']:
                PID = pinfo['pid']
    return PID
print(get_process_id_by_name('WXWork.exe'))