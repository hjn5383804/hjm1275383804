import requests, re
from IMS.API.API_TEST.common.read_excel import ReadExcel



class RequestMethod:
    def __init__(self):
        self.readexcel = ReadExcel('API_mould.xlsx', 'API_mould_sheet_name')
        # 实例化一个Session对象
        self.session = requests.session()
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36",
            "Accept-Language": "zh-CN,zh;q=0.9"}
        self.session.headers.update(headers)

    # 把接口的请求方法GET和POST封装成一个统一的方法
    def requset_method(self, method, url, params=None,files=None):
        """
        上传文件格式：
        files = {‘file‘: open(‘test11.log‘, ‘rb‘)}
        """
        if method == "GET":
            return self.session.get(url, params=params, verify=False)
        elif method == "POST":
            return self.session.post(url, data=params, verify=False)
        elif method=="POST_FILE":
            return self.session.post(url,data=params,files=files,verify=False)

    # 请求接口，获取响应的结果，如果响应的是JSON，就返回字典格式数据；如果响应是XML，就返回字符串格式数据
    def get_actual_result(self, method, url, params=None):
        responseObject = self.requset_method(method, url, params)
        actual = None
        try:
            actual = responseObject.json()
        except:
            actual = responseObject.text
        finally:
            return actual

    """
    执行数据关联用例的思路：1、先获取前置用例的行号；2、根据行号获取method、url、params等，然后执行前置
    用例；3、根据正则表达式从前置用例的响应中提取value，组成键值对；4、把键值对更新到请求参数中；
    5、执行用例，获取实际结果。
    """

    # 获取前置用例的行号
    def get_precondion_case_row(self, row):
        ##前置用例编号
        precondition_case_id = self.readexcel.get_precondition_case_id(row)
        for i in range(2, self.readexcel.get_max_row() + 1):
            ###遍历所有用例编号
            case_id = self.readexcel.get_case_id(i)
            ###
            if case_id == precondition_case_id:
                return i

    # if __name__ == '__main__':
    #     aa=RequestMethod()
    #     for B in range(1,aa.read.get_row_count()+1):
    #         pass
    #         print(aa.get_precondion_case_row(B))

    # 执行前置用例，提取响应，返回键值对
    def get_depend_key_value(self, row):
        # 获取前置用例的行号
        precondition_case_row = self.get_precondion_case_row(row)
        # 获取前置用例的方法、URL、参数
        method = self.readexcel.get_case_method(precondition_case_row)
        url = self.readexcel.get_case_url(precondition_case_row)
        params = self.readexcel.get_case_params_value(precondition_case_row,'params.json')
        # 执行前置用例，获取响应结果
        precondition_case_actual = self.get_actual_result(method, url, params)
        # 使用正则表达式，从响应结果中提取数据
        pattern = self.readexcel.get_re(precondition_case_row)
        value = re.findall(pattern, precondition_case_actual)[0]
        key = self.readexcel.get_depend_field_key(precondition_case_row)
        return {key: value}  ###以字典形式返回参数

    # 执行前置用例，获取键值对，更新到请求参数中，最终返回更新后的请求参数
    def get_updated_case_params_value(self, row):
        if self.readexcel.get_precondition_case_id(row):
            # 获取前置用例提取的键值对
            dict1 = self.get_depend_key_value(row)
            dict2 = self.readexcel.get_case_params_value(row,'params.json')
            ###dict1含有需要的字段，把dict1更新到dict2中
            dict2.update(dict1)
        else:
            dict2 = self.readexcel.get_case_params_value(row,'params.json')
        return dict2


if __name__ == '__main__':
    request = RequestMethod()
    for row in range(2, request.readexcel.get_max_row() + 1):
        if_execute = request.readexcel.get_if_execute(row)
        if if_execute == "Y":
            method = request.readexcel.get_case_method(row)
            url = request.readexcel.get_case_url(row)
            params = request.get_updated_case_params_value(row)
            print("第%d行的参数：%s" % (row, params))
            actual = request.get_actual_result(method, url, params)
            print(actual)
