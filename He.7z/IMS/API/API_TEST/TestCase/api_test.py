import pytest

from IMS.API import ReadExcel


####定义函数获取测试用例中需要用到的值
def get_data():
    read = ReadExcel()
    list1 = []
    totalrow = read.get_row_count()
    for i in range(2, totalrow):
        if_excute = read.get_if_execute(i)
        method = read.get_case_method(i)
        url = read.get_case_url(i)
        exc = read.get_case_expect_value(i)
        datatype = read.get_data_type(i)
        list1.append((if_excute, method, url, exc, datatype, i))
    return list1




class TestAll:
    @pytest.mark.parametrize("if_excute,method,url,datatype,exc,row", get_data())
    def testall(self, get_res_obj, if_excute, method, url, datatype, exc, row):
        if if_excute == "Y":
            params = get_res_obj.get_updated_case_params_value(row)
            actual = get_res_obj.get_actual_result(method, url, params)
            if datatype == "JSON":
                assert exc == actual
            elif datatype == "HTML":
                assert exc in actual


if __name__ == '__main__':
    pytest.main()
