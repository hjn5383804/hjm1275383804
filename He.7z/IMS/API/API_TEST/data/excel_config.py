class ExcelColumn:
    CASE_ID = "B"
    CASE_NAME = "B"
    CASE_METHOD = "C"
    CASE_URL = "D"
    CASE_IF_EXECUTE = "E"
    CASE_PRECONDITION_CASE_ID = "F"
    CASE_DEPEND_FIELD = "G"
    CASE_RE = "H"
    CASE_PARAMS = "I"
    CASE_EXPECT = "J"
    CASE_DATA_TYPE = "K"


class CsvColumn:
    CASE_ID = 0
    CASE_NAME = 1
    CASE_METHOD = 2
    CASE_URL = 3
    CASE_IF_EXECUTE = 4
    CASE_PRECONDITION_CASE_ID = 5
    CASE_DEPEND_FIELD = 6
    CASE_RE = 7
    CASE_PARAMS = 8
    CASE_EXPECT = 9
    CASE_DATA_TYPE = 10
