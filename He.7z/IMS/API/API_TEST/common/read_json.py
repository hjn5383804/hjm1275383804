import json


def read_json(json_path):

    """json.loads() 将json格式转换成python字典类型"""
    with open(json_path, encoding="utf-8") as fp:
        return json.loads(fp.read())

params={"signature":'signature',"time":'time',"logninfo":{"account":'account',"thirdlogin":0,"version":"v123.34.56345673","autologin":0,"platform":0,"country_code":"86","open_id":"","unionid":""},"devinfo":{"devtoken":"","language":"zh-CN","timezone":"UTC 8","autologin":0,"os":"web","pushos":"","userid":'account',"devid":""}}
print(read_json(params))