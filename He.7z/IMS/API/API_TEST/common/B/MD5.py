import hashlib


def hash_encrpty(data):
    """hash加密，不可逆"""
    return hashlib.md5(data.encode('utf-8')).hexdigest()


def SHA1(data):
    return hashlib.sha1(data.encode("utf-8")).hexdigest()


def SHA224(data):
    return hashlib.sha224(data.encode("utf-8")).hexdigest()


def SHA256(data):
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def SHA384(data):
    return hashlib.sha384(data.encode("utf-8")).hexdigest()


def SHA512(data):
    return hashlib.sha512(data.encode("utf-8")).hexdigest()

# d033e22ae348aeb5660fc2140aec35850c4da997
#     hashlib.sha1(data.encode("utf-8")).hexdigest()
print(hashlib.sha1('admin'.encode("utf-8")).hexdigest())
x=SHA1('admin')
print(x)
