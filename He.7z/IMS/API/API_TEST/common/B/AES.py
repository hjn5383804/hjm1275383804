from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
BLOCK_SIZE = 32#block_size 补充位数


def AES_ECB_encrpty(private_key, data):
    """私钥长度一定要是16的倍数而且不能超长,明文不够16字节需要进行补全,返回的是AES已加密的16进制密文"""
    private_key = private_key.encode()
    data = data.encode()
    aes = AES.new(private_key, AES.MODE_ECB)
    return aes.encrypt(pad(data, BLOCK_SIZE))


def AES_ECB_decrpty(private_key, data):
    """参数data为加密后的16进制字符串"""
    private_key = private_key.encode()
    data = bytes.fromhex(data)
    aes = AES.new(private_key, AES.MODE_ECB)
    return unpad(aes.decrypt(data), BLOCK_SIZE).decode('utf-8')



def AES_CBC_encrpty(private_key, data, iv):
    """加密和解密不能调用同一个aes对象"""
    private_key = private_key.encode()
    data = data.encode()
    iv = iv.encode()
    aes = AES.new(private_key, AES.MODE_CBC, iv)
    return aes.encrypt(pad(data, BLOCK_SIZE)).hex()


def AES_CBC_decrpty(private_key, data, iv):
    private_key = private_key.encode()
    #将16进制数据转换为字节类型数据
    data = bytes.fromhex(data)
    iv = iv.encode()
    aes = AES.new(private_key, AES.MODE_CBC, iv)
    return unpad(aes.decrypt(data), BLOCK_SIZE).decode('utf-8')


# a=AES_ECB_encrpty('1234567812345678','一二三四')
# print(a)
#
# print(AES_ECB_decrpty('1234567812345678','59168eff7540324924d9602c5f897d7fe7fd6cbe73a9db31e9f03a15f2e53f32'))
#
# print(AES_CBC_encrpty('1234567812345678','abcdefghijklmnhi','1234567812345678'))
#
# print(AES_CBC_decrpty('1234567812345678','938b4e21e77e3eb04dba91ab37343b3031b6b04199e50731c0b8ee73c8658b9f','1234567812345678'))

# \x93\x8bN!\xe7~>\xb0M\xba\x91\xab74;0
# \x93\x8bN!\xe7~>\xb0M\xba\x91\xab74;01\xb6\xb0A\x99\xe5\x071\xc0\xb8\xees\xc8e\x8b\x9f
