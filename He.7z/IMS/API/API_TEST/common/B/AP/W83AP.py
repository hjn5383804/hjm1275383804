import requests

from API.API_TEST.common.B.Encrpty import Encrpty


class W83AP(object):
    def init_ip(self,DUT_ip):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
            "Content-Type": "application/json",
            "Connection": "keep-alive",
        }
        self.url='http://{}/goform/modules'.format(DUT_ip)
        self.session = requests.Session()
    def login(self):
        params = {
            "sysLogin": {
                "username": "admin",
                "password": "YWRtaW4=",
                "logoff": "false",
            }
        }
        r_login = self.session.post(url=self.url, json=params, headers=self.headers, timeout=(5,10))
        return r_login.json()
    def ucloud_on(self,ucloudId):
        params={"ucloudSet": {"ucloudEn": "true", "ucloudMode": "1", "ucloudId": ucloudId,"ucMsgReport": "1"}}
        r_ucloud_on = self.session.post(url=self.url, json=params, headers=self.headers, timeout=(5,10))
        return r_ucloud_on.json()
x=W83AP()
x.init_ip('192.168.1.190')
print(x.login())
print(x.ucloud_on('7583e5bc7e395cb8f2f426d6c8e17ddc'))