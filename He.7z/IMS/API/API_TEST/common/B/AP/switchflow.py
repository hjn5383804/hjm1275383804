class switchflow(object):
    def f(self,data):
        flag = 0
        type = ["B", "KB", "MB", "GB", "TB"]
        while True:
            if data > 1024:
                data /= 1024
                flag += 1
            else:
                break
        return str(round(data,2))+type[flag]
t=14075560
print(switchflow().f(t))
