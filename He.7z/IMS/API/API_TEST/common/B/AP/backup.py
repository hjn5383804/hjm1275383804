from TMP.test.W36_login import switch_to_dict
import requests
ip = '192.168.0.167'
login_URL = 'http://{}/login/Auth'.format(ip)
header = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
    "Connection": "keep-alive",
}
login_data = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
login_params = switch_to_dict(login_data)
s = requests.Session()
res = s.post(url=login_URL, data=login_params, headers=header, timeout=3)
assert 'version=' in res.text
print("登录成功")
for i in range(1000):
    try:
        res=s.get('http://192.168.0.167/cgi-bin/DownloadCfg/APCfm.cfg')
        print(res.content)
    except:
        pass
