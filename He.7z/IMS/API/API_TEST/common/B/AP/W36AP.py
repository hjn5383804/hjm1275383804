import base64
import time

import requests
class W36AP(object):

    def base64_encrypt(self, data):
        """base64加密"""
        obj = base64.b64encode(data.encode())
        return obj.decode()
    def switch_to_dict(self,str):
        """将get传参的请求数据如：'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin',转换为字典"""
        global index
        list_i = []
        dict_i = {}
        temp = 'THIS IS A TEMP'
        #%3B解析出来就是分号，不用传登录时的时间戳，也是可以登录成功的
        str = str.replace('%3B', ";")
        str = str.split("&")
        for i in str:
            if i.count("=") > 1:
                # 获取第一个"="的位置
                index = i.find("=")
                x = i.replace(i[index], temp, 1)
                i = x.split(temp)
            else:
                i = i.split("=")
            list_i.append(i)
        for j in list_i:
            dict_j = {j[0]: j[1]}
            dict_i.update(dict_j)
        return dict_i
    def 初始化W36AP地址(self,ip):
        self.ip=ip
        self.header={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
            "Connection": "keep-alive",
            "Host":"{}".format(self.ip)
        }
        self.s = requests.Session()
    def W36AP登录(self, password='admin'):
        password = self.base64_encrypt(password)
        login_URL = 'http://{}/login/Auth'.format(self.ip)
        login_data = 'usertype=admin&password={}&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'.format(password)
        login_params = self.switch_to_dict(login_data)

        self.s.post(url=login_URL, data=login_params, headers=self.header, timeout=(5,10))

    def W36AP开启云维护(self,ucloudId):
        ucloud_data_on = 'GO=cloud_manage.asp&ucloudEn=true&ucloudMode=1&ucloudId={}&ucMsgReport=true&radio=2.4G'.format(ucloudId)
        ucloud_URL = 'http://{}/goform/ucloudSet'.format(self.ip)
        ucloud_params_on = self.switch_to_dict(ucloud_data_on)
        res = self.s.post(url=ucloud_URL, data=ucloud_params_on, headers=self.header, timeout=(5,10))
        return res.json()

    def W36AP关闭云维护(self, ucloudId):
        ucloud_data_off = 'GO=cloud_manage.asp&ucloudEn=false&ucloudMode=1&ucloudId={}=false&radio=2.4G'.format(ucloudId)
        ucloud_URL = 'http://{}/goform/ucloudSet'.format(self.ip)
        ucloud_params_off = self.switch_to_dict(ucloud_data_off)
        res = self.s.post(url=ucloud_URL, data=ucloud_params_off, headers=self.header, timeout=(5, 10))
        return res.json()

x=W36AP()
x.初始化W36AP地址('192.168.0.167')
x.W36AP登录()
while True:
    print(x.W36AP开启云维护('444c1f24d25c2fb079301a7875ec9300'))
    time.sleep(180)
    print(x.W36AP关闭云维护('444c1f24d25c2fb079301a7875ec9300'))