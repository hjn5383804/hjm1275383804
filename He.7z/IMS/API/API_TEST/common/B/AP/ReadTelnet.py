import logging
import telnetlib
import time
import requests
import re
class ReadTelnet(object):

    def telnet_W83AP(self,command, ip):
        """适用于W83AP、W63AP、W64AP、W80AP
        command:命令
        ip：AP的地址
        """
        session = requests.Session()
        params_login = {
            "sysLogin": {
                "username": "admin",
                "password": "YWRtaW4=",
                "logoff": "false",
            }
        }
        for i in range(3):
            resp = session.post('http://{}/goform/modules'.format(ip), json=params_login, timeout=(5,10))
            resp_text = str(resp.text)
            exp = '{"sysLogin":{"userType":"admin","Login":true,"logoff":false}}'
            if exp == resp_text:
                print("telnet初始化登录成功")
                break
        time.sleep(1)
        session.get('http://{}/goform/telnet'.format(ip))
        tn = telnetlib.Telnet()
        try:
            tn.open(host='{}'.format(ip), port=23, timeout=3)
        except:
            logging.warning('网络连接失败')
            return False
        # 账号浮标
        tn.read_until(b'login: ', timeout=3)
        tn.write("root".encode('ascii') + b'\n')
        # 密码浮标
        tn.read_until(b'Password: ', timeout=3)
        tn.write("Fireitup".encode('ascii') + b'\n')
        tn.write(command.encode('utf-8') + b'\n')
        time.sleep(2)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8', 'ignore').replace(command, "").replace('root@W83AP:~#',"")
        # 退出telnet
        tn.write(b"exit")
        return r

    def switch_to_dict(self,str):
        """将get传参的请求数据如：'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin',转换为字典"""
        global index
        list_i = []
        dict_i = {}
        temp = 'THIS IS A TEMP'
        #%3B解析出来就是分号，不用传登录时的时间戳，也是可以登录成功的
        str = str.replace('%3B', ";")
        str = str.split("&")
        for i in str:
            if i.count("=") > 1:
                # 获取第一个"="的位置
                index = i.find("=")
                x = i.replace(i[index], temp, 1)
                i = x.split(temp)
            else:
                i = i.split("=")
            list_i.append(i)
        for j in list_i:
            dict_j = {j[0]: j[1]}
            dict_i.update(dict_j)
        return dict_i
    def telnet_W36AP(self,command,ip):
        """适用于W83AP、W63AP、W64AP、W80AP
        command:命令
        ip：AP的地址
        """
        login_URL = 'http://{}/login/Auth'.format(ip)
        login_params = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
        login_params = self.switch_to_dict(login_params)
        s = requests.Session()
        for i in range(3):
            res = s.post(url=login_URL, data=login_params, timeout=(5,10))
            if '登录成功' in res.text:
                print("登录成功")
            break
        s.get('http://{}/goform/telnet'.format(ip))
        tn = telnetlib.Telnet()
        try:
            tn.open(host='{}'.format(ip), port=23, timeout=3)
        except:
            logging.warning('网络连接失败')
            return False
        # 账号浮标
        tn.read_until(b'login: ', timeout=3)
        tn.write("root".encode('ascii') + b'\n')
        # 密码浮标
        tn.read_until(b'Password: ', timeout=3)
        tn.write("Fireitup".encode('ascii') + b'\n')
        tn.write(command.encode('utf-8') + b'\n')
        time.sleep(2)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8', 'ignore').replace(command, "").replace('~ # ', "")
        # 退出telnet
        tn.write(b"exit")
        return r
x=ReadTelnet()
data=x.telnet_W83AP('uci show | grep env_sn','192.168.1.190')
print("data***********",data)
# y=re.findall('IPCOM\d+',data)
# print(y[0])