from API.API_TEST.common.B.imstoken import get_token
import json
token=get_token().get_token('18281123892','123456')
print(token)
token=token.get( 'access_token')
print(token)