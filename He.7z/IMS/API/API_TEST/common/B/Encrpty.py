import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64
BLOCK_SIZE = 16#block_size 补充位数
class Encrpty(object):
    """hash加密，不可逆,返回十六进制字符"""

    def md5_encrpty(self,data):
        return hashlib.md5(data.encode('utf-8')).hexdigest()

    def SHA1(self,data):
        return hashlib.sha1(data.encode("utf-8")).hexdigest()

    def SHA224(self,data):
        return hashlib.sha224(data.encode("utf-8")).hexdigest()

    def SHA256(self,data):
        return hashlib.sha256(data.encode("utf-8")).hexdigest()

    def SHA384(self,data):
        return hashlib.sha384(data.encode("utf-8")).hexdigest()

    def SHA512(self,data):
        return hashlib.sha512(data.encode("utf-8")).hexdigest()

    def AES_ECB_encrpty(self,private_key, data):
        """私钥长度一定要是16的倍数而且不能超长,明文不够16字节需要进行补全,返回的是AES已加密的16进制字符串"""
        private_key = private_key.encode()
        data = data.encode()
        aes = AES.new(private_key, AES.MODE_ECB)
        return aes.encrypt(pad(data, BLOCK_SIZE))

    def AES_ECB_decrpty(self,private_key, data):
        """参数data为加密后的16进制字符串"""
        private_key = private_key.encode()
        data = bytes.fromhex(data)
        aes = AES.new(private_key, AES.MODE_ECB)
        return unpad(aes.decrypt(data), BLOCK_SIZE).decode('utf-8')

    def AES_CBC_encrpty(self,private_key, data, iv):
        """加密和解密不能调用同一个aes对象"""
        private_key = private_key.encode()
        data = data.encode()
        iv = iv.encode()
        aes = AES.new(private_key, AES.MODE_CBC, iv)
        return aes.encrypt(pad(data, BLOCK_SIZE)).hex()

    def AES_CBC_decrpty(self,private_key, data, iv):
        #CBC解密
        private_key = private_key.encode()
        # 将16进制数据转换为字节类型数据
        data = bytes.fromhex(data)
        iv = iv.encode()
        aes = AES.new(private_key, AES.MODE_CBC, iv)
        return unpad(aes.decrypt(data), BLOCK_SIZE).decode('utf-8')

    def base64_encrypt(self,data):
        """base64加密"""
        obj = base64.b64encode(data.encode())
        return obj.decode()

    def base64_decrpyt(self,data):
        """base64解密"""
        ciphertext_str = base64.b64decode(data)
        return ciphertext_str.decode()

