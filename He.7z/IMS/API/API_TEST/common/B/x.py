from openpyxl import load_workbook
from API.API_TEST.data.excel_config import ExcelColumn
# 登录测试
    # [Template]    登录测试-数据驱动
    # #用例描述    账号    密码    预期结果1    断言类型
    # 账号1正常登录    18583382064    123456    {'resp_code': 0, 'access_token': '$token$', 'expired_time': 259200}    响应码0
    # 账号2正常登录    18281123892    123456    {'resp_code': 0, 'access_token': '$token$', 'expired_time': 259200}    响应码0
    # 账号3错误密码登录    18281123892    1234567    {'resp_code': 6, 'access_token': '', 'expired_time': 0}    响应码6
    # 账号为空登录    \    123456    {'resp_code': 4, 'access_token': '', 'expired_time': 0}    响应码4
    # 账号密码均为空登录    \    \    {'resp_code': 4, 'access_token': '', 'expired_time': 0}    响应码4

# class ReadExcel:
#     def init_excel(self, excel_path,sheet_name):
#         """传excel文件路径"""
#         self.excel_path = excel_path
#         # 前往excel文件sheet页
#         wb = load_workbook(excel_path)
#         self.ws = wb[(sheet_name)]
#
#     # 声明一个方法来获取单元格的值
#     def get_cell_value(self, column, row):
#         """ws['xy']：获取excel表格某坐标的值"""
#         return self.ws[column + str(row)].value

    # 获取用例编号
    # def get_case_id(self, row):
    #     return self.get_cell_value(ExcelColumn.CASE_ID, row)


# excel=ReadExcel()
# excel.init_excel('E:/IMS-API.xlsx','项目管理')
# import re
# #参数为签名、时间戳、账户名
# psot_data='{"signature":"$signature$","time":$time$,"logninfo":{"account":"$account$","thirdlogin":0,"version":"v123.34.56345673","autologin":0,"platform":0,"country_code":"86","open_id":"","unionid":""},"devinfo":{"devtoken":"","language":"zh-CN","timezone":"UTC 8","autologin":0,"os":"web","pushos":"","userid":"$account$","devid":""}}'
# headers={"Content-Type": "application/json","Token":"$token$","AccessType":"web","ProjectId":"$ProjectId$"}
# signature='123456'
# time=654321
# account=18888888888
# signature_params=['合法值','非法值','空值']
# def parameterized_body(key,value,post_data):
#     return re.sub('\\${}\\$'.format(key),value,post_data)
# def parameterized_head(key,value,head):
#     return re.sub('\\${}\\$'.format(key),value,head)
#
# s={"account":"18583382064","access_token":"b3629c525c420c8b99d06ebe0bfa1f6a"}
# x={'project_list': [{'id': 715578, 'status': 0, 'project_name': '3', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['广东省', '深圳市', '南山区'], 'address': '', 'create_type': 0, 'user_num': 0, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 0, 'offline_dev': 0, 'create_time': '2022-07-25 09:54:44', 're_time': 0, 'type_flag': 0}, {'id': 715577, 'status': 0, 'project_name': '2', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['广东省', '深圳市', '南山区'], 'address': '', 'create_type': 0, 'user_num': 0, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 0, 'offline_dev': 0, 'create_time': '2022-07-25 09:54:39', 're_time': 0, 'type_flag': 0}, {'id': 715576, 'status': 0, 'project_name': '1', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['广东省', '深圳市', '南山区'], 'address': '', 'create_type': 0, 'user_num': 0, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 0, 'offline_dev': 0, 'create_time': '2022-07-25 09:54:34', 're_time': 0, 'type_flag': 0}, {'id': 715575, 'status': 1, 'project_name': 'new_project', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['四川省', '成都市', '高新'], 'address': '', 'create_type': 0, 'dev_num': {'ap': 1}, 'user_num': 1, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 1, 'offline_dev': 0, 'create_time': '2022-07-25 09:47:29', 're_time': 0, 'type_flag': 0}, {'id': 715574, 'status': 0, 'project_name': 'new_project', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['四川省', '成都市', '高新'], 'address': '', 'create_type': 0, 'user_num': 0, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 0, 'offline_dev': 0, 'create_time': '2022-07-25 09:42:32', 're_time': 0, 'type_flag': 0}, {'id': 500000, 'status': 1, 'project_name': '标准组网演示项目', 'net_mode': 0, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['xx', 'yy', 'zz'], 'address': '', 'create_type': 0, 'dev_num': {'ap': 200, 'router': 1, 'switch': 10}, 'user_num': 5, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 211, 'offline_dev': 204, 'create_time': '2022-01-11 08:40:46', 're_time': 0, 'type_flag': 0}, {'id': 600000, 'status': 1, 'project_name': '免布线演示项目', 'net_mode': 1, 'type': 'hotel', 'right': 'rw', 'is_share': 0, 'owner': '', 'cloudId': '', 'location': ['xx', 'yy', 'zz'], 'address': '', 'create_type': 0, 'dev_num': {'mesh': 10}, 'user_num': 50, 'warn_num': 0, 'rate_info': {'up_rate': '', 'down_rate': ''}, 'total_dev': 10, 'offline_dev': 0, 'create_time': '2020-12-02 16:45:19', 're_time': 0, 'type_flag': 0}], 'resp_code': 0}
# id_list=[]
# project_list=x.get('project_list')
# for i in project_list:
#     id=i.get(('id'))
#     print(id)
#     print(type(id))
#     if id!=500000 and id !=600000:
#         id_list.append(id)
# print(id_list)
# x="wireless.radio0.country='CN'"

# with open('E:/e.log','r',errors='ignore') as f:
#     data=f.read()
#     data.replace("\n","")
#     print(data)

# #a和b对调
# a='a'
# b='b'
# a,b=b,a
# print(a,b)
#
# #a和b对调
# a='a'
# b='b'
# c=a
# a=b
# b=c
# print(a,b)

x=[1,2,3,4,5,6,7,8]
print(x[0])
print(x[-1])