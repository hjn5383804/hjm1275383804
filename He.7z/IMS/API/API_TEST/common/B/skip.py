import json
class skip(object):
    def remove_sk(self,json_data):
        return json.dumps(json_data,separators=(',', ':'))

x={"signature": "881da873ab413cddae8f5db5032180ff667295c97e87e94e003956d40828906dab3943c6057a47eecf1e184dc1078095", "time": 1658302273951, "logninfo": {"account": "18281123892", "thirdlogin": 0, "version": "v123.34.56345673", "autologin": 0, "platform": 0, "country_code": "86", "open_id": "", "unionid": ""}, "devinfo": {"devtoken": "", "language": "zh-CN", "timezone": "UTC 8", "autologin": 0, "os": "web", "pushos": "", "userid": "$account$", "devid": "", "account": "18281123892"}}
print(skip().remove_sk(x))