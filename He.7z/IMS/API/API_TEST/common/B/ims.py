'''
@Author:wujunjie
@Description:
IMS和安防项目登录接口生成sign签名的加密算法
'''

import hashlib
import json
import time
from Crypto.Cipher import AES
import base64
import binascii

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import algorithms


class HandleSignLibrary(object):

    def bytes_To_HexString(self, bytes):
        """字节转16进制hex字符串，返回转换后的字符串.
        :argument   ${str}
        return ${hexString}

        Examples:
        | ${hexString} = | bytes To HexString | ${bytes} |
        """
        return ''.join(['%02X' % b for b in bytes]).lower()

    def sha1_encrypt(self, str):
        """对字符串进行sha1加密，返回加密后的字符串.
        :argument   ${str}
        return ${sha1_encrypt_str}

        Examples:
        | ${sha1_encrypt_str} = | Sha1 Encrypt | ${str} |
        """
        sha = hashlib.sha1(str.encode('utf-8'))
        sha1_encrypt_str = sha.hexdigest()
        return sha1_encrypt_str

    def md5_encrypt(self, str):
        """对字符串进行MD5加密，返回加密后的字符串.
        :argument   ${str}
        return ${md5_encrypt_str}

        Examples:
        | ${md5_encrypt_str} = | md5 Encrypt | ${str} |
        """
        md5 = hashlib.md5()
        md5.update(str.encode('utf-8'))
        md5_encrypt_str = md5.hexdigest()
        return md5_encrypt_str

    def pkcs7_padding(self, data):
        """aes cbc加密模式中的pkcs7_padding填充.
        :argument   ${data}
        return ${padded_data}

        Examples:
        | ${padded_data} = | pkcs7 padding | ${data} |
        """

        padder = padding.PKCS7(algorithms.AES.block_size).padder()

        padded_data = padder.update(data) + padder.finalize()

        return padded_data




    def AES_encrypt(self, message, mdkey, iv, model):
        """AES加密.
         :argument   ${message} ${mdkey}    ${iv}   ${model}
         return ${encrypt_text}

         Examples:
         | ${encrypt_text} = | AES encrypt | ${message} | ${mdkey} | ${iv} | ${model} |
         """
        self.aes = AES.new(mdkey, model, iv)
        self.encrypt_text = self.aes.encrypt(self.pkcs7_padding(message))
        return self.bytes_To_HexString(self.encrypt_text)


    def get_timestamp(self):
        """获取当前系统时间时间戳，*1000表示返回的是时间戳的整数.
            return ${timestamp}

            Examples:
            | ${timestamp} = | get timestamp |
            """
        return int(time.time() * 1000)

    def get_ims_sign(self, username, password):
        """IMS 根据账号，密码，时间搓生成签名

1.初始signature:	md5(md5(pwd)+"tenday"+time)
2.初始key:		key=version,如果key.length<16,在key的后面补a,补足16位
3.初始mdDevInfo:	md5(logininfo的json字符串)
4.massage:	初始signature的utf8编码
5.mdkey:		初始key的utf8编码
6.iv:		mdDevInfo的后16位的utf8编码
7.AES加密：	massage,mdkey,{mode:cbc,padding:pkcs7,iv}
8.转为hex:		将加密后的数据转换成hex

        return ${imssign}   ${timestamp}

        Examples:
        | ${imssign} = | get ims sign | account | password | timestamp |
        """

        # 1.初始signature: md5(md5(pwd) + "tenday" + time)
        # timestamp = self.get_timestamp()
        timestamp = 1657852397902
        signature = self.md5_encrypt(self.md5_encrypt(password) + 'tenday' + str(timestamp))
        print('初始化sign', signature)

        # 2.初始key: key = version, 如果key.length < 16, 在key的后面补a, 补足16位
        # key = logininfo['version']
        key = 'v123.34.56345673'
        if (len(key) < 16):
            numChar = 16 - (len(key) % 16)
            i = 1
            while i < numChar:
                key = key + 'a'
                i += i
        else:
            key = key[:16]

        print('key', key)

        # 3.初始mdDevInfo: md5(logininfo的json字符串)
        # mdDevInfo = self.md5_encrypt(json.dumps(logininfo))
        login_info = "{\"account\":\"" + username + "\",\"thirdlogin\":0,\"version\":\"v123.34.56345673\",\"autologin\":0,\"platform\":0,\"country_code\":\"86\",\"open_id\":\"\",\"unionid\":\"\"}"
        print(login_info)
        mdDevInfo = self.md5_encrypt(login_info)
        print('mdDevinfo:', mdDevInfo)
        # 4.message: 初始signature的utf8编码
        message = signature.encode('utf-8')
        # 5.mdkey: 初始key的utf8编码
        mdkey = key.encode('utf-8')
        print('mdkey', mdkey)
        # 6.iv: mdDevInfo的后16位的utf8编码
        iv = mdDevInfo[len(mdDevInfo) - 16:len(mdDevInfo)].encode('utf-8')
        print("iv", iv)
        # 7.AES加密：    massage, mdkey, {mode: cbc, padding: pkcs7, iv}
        cipher = self.AES_encrypt(message=message, mdkey=mdkey, iv=iv, model=AES.MODE_CBC)
        print("cipher", cipher)

        return cipher, timestamp

    def get_security_sign(self, username, password):
        pass


if __name__ == '__main__':
    sl = HandleSignLibrary()
    y=sl.bytes_To_HexString(b"\xc9\x11\xa9Y5\xde\xe6\xfe\xf1\rB\tm\xca7\xc2\xc3\xf2E\x9f\x04\xe7:'\xc3\xc2\xca\xc7y\xb4\xad\xa8")
    print(y)
    print(b"\xc9\x11\xa9Y5\xde\xe6\xfe\xf1\rB\tm\xca7\xc2\xc3\xf2E\x9f\x04\xe7:'\xc3\xc2\xca\xc7y\xb4\xad\xa8".hex())
    ad=sl.sha1_encrypt('admin')
    print(ad)
    print(type(ad))
    print(hashlib.sha1('admin'.encode("utf-8")).hexdigest())
    account = '18583382064'
    password = '123456'
    # timestamp = 1656557248239
    # login_info = "{\"account\":\"13208170776\",\"thirdlogin\":0,\"version\":\"v123.34.56345673\",\"autologin\":0,\"platform\":0,\"country_code\":\"86\",\"open_id\":\"\",\"unionid\":\"\"}"
    pwd = sl.md5_encrypt(password)
    print('pwd', pwd)
    sign = sl.get_ims_sign(account, password)
    hexstring = sl.bytes_To_HexString(password.encode('utf-8'))
    print('hexstring:  ', hexstring)
    print("预期sign", 'a81d55736bc315f746c85ff262dd14dd7f8f34f0eb9c2ac64e21f8da162af4f981367365d3bfc634bd3bd2c158762aee')
    print("生成sign", sign)
