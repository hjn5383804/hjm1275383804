import base64


def encrypt(data):
    """base64加密"""
    obj = base64.b64encode(data.encode())
    return obj.decode()


def decrpyt(data):
    """base64解密"""
    ciphertext_str = base64.b64decode(data)
    return ciphertext_str.decode()


print(encrypt('admin'))
print(decrpyt('YWRtaW4='))