import time
import json
from API.API_TEST.common.B.Encrpty import Encrpty
class signature():
    def get_signature(self,account,password):
        timestamp = int(time.time() * 1000)
        login_info = {
            "account": "{}".format(account),
            "thirdlogin": 0,
            "version": "v123.34.56345673",
            "autologin": 0,
            "platform": 0,
            "country_code": "86",
            "open_id": "",
            "unionid": ""
        }
        # 调试用的时间戳：
        # timestamp=1658122817130
        encrpty = Encrpty()
        # 1.初始化signature
        signature = encrpty.md5_encrpty(encrpty.md5_encrpty(password) + 'tenday' + str(timestamp))
        # print('signature',signature)
        # 2.初始key: key = version, 如果key.length < 16, 在key的后面补a, 补足16位
        key = login_info['version']
        if len(key) < 16:
            while True:
                key += 'a'
                if len(key) == 16:
                    break
        else:
            key = key[:16]
        # print('key',key)
        # 3.初始化login_info

        login_info = json.dumps(login_info).replace(" ","")
        md5_encrpty_login_info = encrpty.md5_encrpty(login_info)
        #4.md5加密后的login_info的后16位得到iv
        iv=md5_encrpty_login_info[len(md5_encrpty_login_info)-16:]
        # print('iv',iv)
        #6.AES-CBC加密得到signature
        signature=encrpty.AES_CBC_encrpty(data=signature,private_key=key,iv=iv)
        return signature,timestamp


