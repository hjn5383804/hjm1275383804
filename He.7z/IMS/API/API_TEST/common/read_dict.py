import json


def read_dict(json_path):
    """json.dumps() 将Python 字典类型转换为 JSON 对象"""
    with open(json_path, encoding="utf-8") as fp:
        return json.dumps(fp.read())