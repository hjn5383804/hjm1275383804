from API.API_TEST.common import read_json
from API.API_TEST.common.read_ini import ReadIni

from openpyxl import load_workbook

class Column:
    CASE_ID = "B"
    CASE_TITLE = "B"
    CASE_METHOD = "C"
    CASE_URL = "D"
    CASE_IF_EXECUTE = "E"
    CASE_PRECONDITION_CASE_ID = "F"
    CASE_DEPEND_FIELD = "G"
    CASE_RE = "H"
    CASE_PARAMS = "I"
    CASE_EXPECT = "J"
    CASE_DATA_TYPE = "K"


class ReadExcel:
    def __init__(self, excel_path,sheet_name):
        """传excel文件路径"""
        excel_path = ReadIni().get_excel_path(excel_path)
        # 前往excel文件sheet页
        wb = load_workbook(excel_path)
        self.ws = wb[ReadIni().get_sheet_name(sheet_name)]

    # 声明一个方法来获取单元格的值
    def get_cell_value(self, column, row):
        """ws['xy']：获取excel表格某坐标的值"""
        return self.ws[column + str(row)].value

    # 获取用例编号
    def get_case_id(self, row):
        return self.get_cell_value(ExcelColumn.CASE_ID, row)

    # 获取用例标题
    def get_case_name(self, row):
        return self.get_cell_value(ExcelColumn.CASE_NAME, row)

    # 获取请求方法
    def get_case_method(self, row):
        return self.get_cell_value(ExcelColumn.CASE_METHOD, row)

    # 获取请求URL
    def get_case_url(self, row):
        return self.get_cell_value(ExcelColumn.CASE_URL, row)

    # 获取请求参数的关键字
    def get_case_params_key(self, row):
        return self.get_cell_value(ExcelColumn.CASE_PARAMS, row)

    # 获取请求参数的值
    def get_case_params_value(self, row, request_json_path):
        if self.get_case_params_key(row):
            self.params_json = ReadIni().get_requests_json_path(request_json_path)
            return read_json(self.params_json)[self.get_case_params_key(row)]

    # 获取预期结果的关键字
    def get_case_expect_key(self, row):
        return self.get_cell_value(ExcelColumn.CASE_EXPECT, row)

    # 获取预期结果的值
    def get_case_expect_value(self, row, expect_json_path):
        if self.get_case_expect_key(row):
            self.expect_json = ReadIni().get_expect_json_path(expect_json_path)
            return read_json(self.expect_json)[self.get_case_expect_key(row)]

    # 获取表的行数
    def get_max_row(self):
        return self.ws.max_row

    # 获取表的列数
    def get_max_column(self):
        return self.ws.max_column

    # 获取响应的数据类型
    def get_data_type(self, row):
        return self.get_cell_value(ExcelColumn.CASE_DATA_TYPE, row)

    # 获取前置用例id
    def get_precondition_case_id(self, row):
        return self.get_cell_value(ExcelColumn.CASE_PRECONDITION_CASE_ID, row)

    # 获取依赖字段
    def get_depend_field_key(self, row):
        return self.get_cell_value(ExcelColumn.CASE_DEPEND_FIELD, row)

    # 获取正则表达式
    def get_re(self, row):
        return self.get_cell_value(ExcelColumn.CASE_RE, row)

    # 获取是否执行的字段
    def get_if_execute(self, row):
        return self.get_cell_value(ExcelColumn.CASE_IF_EXECUTE, row)


if __name__ == '__main__':
    read = ReadExcel('API_mould.xlsx', 'API_mould_sheet_name')
    print("文件总行数：", read.get_max_row(), "文件总列数：", read.get_max_column())
    max_row = read.get_max_row()
    # 遍历所有用例
    for row in range(2, max_row + 1):
        print(read.get_case_id(row))
        print(read.get_case_name(row))
        print(read.get_case_method(row))
        print(read.get_case_url(row))
        print(read.get_case_params_value(row,'params.json'))
        print(read.get_case_expect_value(row,'expect.json'))
