def add(x, y, *args):
    c = x + y
    list1 = []
    for i in args:
        list1.append(i)
    return c, list1


print(add(1, 2, 3, 4)[1])


def e(x):
    if x != 1:
        return x * e(x - 1)
    else:
        return 1


print(e(6))


def aa(a, b, c):
    s1 = a + b
    s2 = a + c
    s3 = b + c
    return s1, s2, s3


yy = aa(1, 2, 3)
print(yy)


