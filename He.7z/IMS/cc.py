# import  os
# data=os.popen('ping 1.2.4.8')
# y=data.read()
# print(y)
# print(type(y),y)
# assert '100% 丢失' not in y
# print(1)


# -*- coding: utf-8 -*-
# import os
# exit_code = os.popen('ping 114.114.114.11 -n 1')
# text = exit_code.read()
# # print(text)
# assert '100% 丢失' not in text
# print(111)
