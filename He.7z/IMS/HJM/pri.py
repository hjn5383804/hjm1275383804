class pri():

    def p1(self):
        print(1)
    def p2(self):
        print(2)
