from HJM import pri

class MyLibrary(pri):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'




