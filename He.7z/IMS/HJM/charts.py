from pyecharts import options as opts
from pyecharts.charts import Line
js_code_str= """
            function(params){
                return params.data[2]+':'+params.data[1];
            }
            """
# 准备数据
x_data = ['12:00', '13:00', '14:00', '15:00', '16:00']
y_data = [10.28, 11.20, 10.15, 12.25, 9.30]

# 创建柱状图
bar_chart = Line()
bar_chart.add_xaxis(x_data)
bar_chart.add_yaxis(series_name='MB',y_axis=y_data)

# 配置全局属性
bar_chart.set_global_opts(
    title_opts=opts.TitleOpts(title="可用内存监测图", subtitle="副标题"),
    xaxis_opts=opts.AxisOpts(name="时间"),
    yaxis_opts=opts.AxisOpts(name="可用内存（MB）"),
    legend_opts=opts.LegendOpts(pos_left="center", pos_top="top"),
    # toolbox_opts=opts.ToolboxOpts(),
    tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
)

# 渲染图表
bar_chart.load_javascript()
bar_chart.render("test.html")