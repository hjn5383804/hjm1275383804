
from playwright.sync_api import sync_playwright
with sync_playwright() as sp:
    chromium = sp.chromium
    browser = chromium.launch(channel="chrome", headless=False)
    context = browser.new_context()
    page = browser.new_page()

    with page.expect_popup() as popup_info:
        page.locator("#open").click()
    popup = popup_info.value

    popup.wait_for_load_state()
    print(popup.title())