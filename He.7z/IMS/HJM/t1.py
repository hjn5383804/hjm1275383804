# 给定一个int数组A及其大小n以及需查找的和sum，请返回数组中两数之和为sum的整数对的个数。保证数组大小小于等于10000。
from functools import reduce

list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
sum = 10
count = 0
for i in list1:
    for j in list1:
        if i == j:
            continue
        if i + j == sum:
            count += 1
print(count / 2)


def func(s, i, j):
    # 递归函数先执行这轮才可以继续下一轮
    if i < j:
        func(s, i + 1, j - 1)
        s[i], s[j] = s[j], s[i]


"""        
i=0, j=5,s=[3, 6, 23, -90, 0, 10]
i=1,j=4,s= [3, 0, 23, -90, 6, 10]   
i=2,j=3,s= [3, 0, -90, 23, 6, 10]        
i=3,j=2,s= [3, 0, -90, 23, 6, 10]          
"""

a = [10, 6, 23, -90, 0, 3]
func(a, 0, len(a) - 1)
print(a)
# def main():
#     a = [10, 6, 23, -90, 0, 3]
#     func(a, 0, len(a) - 1)
#     for i in range(6):
#         print(a[i])
#         print("\n")
#
#
# main()
strs = 'I like python'
one = strs.find('a')
print(one)
two = strs.index('k')
print(two)

"""
a=10,b=6
a=6,b=4
a=4,b=2
a=2,b=0
"""
import math

counter = 1


def doLotsOfStuff():
    global counter
    for i in (1, 2, 3):
        counter += 1


doLotsOfStuff()
print(counter)
l = [9.2,
     9.2,
     11.2,
     9.6,
     10.8,
     9.6,
     9.5,
     9.3,
     9.5,
     9.4,
     9.4,
     10.4,
     12,
     9.8,
     10.1,
     11.8,
     9.5,
     11.5,
     9.9
    ]
l2=[]
for i in l:
    i=i-1.5
    l2.append(i)
print(l2)
x=reduce(lambda x,y:x+y,l2)/len(l2)
print(x)

dict3 = {[1,2,3]: "uestc"}
print(dict3)