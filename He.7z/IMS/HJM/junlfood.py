import random
import time
from pynput.keyboard import Key, Controller

import win32api
import win32con

from UI.WEB.COM.base import base
# data_list=['关爱智障孩童李强-爱心1群','关爱智障孩童李强-爱心2群']
data="热烈庆祝吾儿李强与马开丽结婚10周年，爸爸永远爱你，我的好强儿"
class JunkFood(base):
    def clickLeftCur(self):
       win32api.mouse_event(
        win32con.MOUSEEVENTF_LEFTDOWN|
       win32con.MOUSEEVENTF_LEFTUP, 0, 0)
    def auto_junk(self):
        #ctrl+C
        # data=random.choice(data_list)
        # pyperclip.copy(data)
        # pyperclip.paste()
        #点击
        # self.clickLeftCur()
        # time.sleep(2)
        #crtl+A,V
        keyboard = Controller()
        # with keyboard.pressed(Key.ctrl):
        #     keyboard.press('a')
        #     keyboard.release('a')
            # time.sleep(0.5)
        with keyboard.pressed(Key.ctrl):
            keyboard.press('v')
            keyboard.release('v')
            # time.sleep(0.5)
        #enter
        keyboard.press(Key.enter)
        keyboard.release(Key.enter)
        time.sleep(5)

while True:
    try:
        jk=JunkFood()
        jk.auto_junk()
    except:
        pass

 