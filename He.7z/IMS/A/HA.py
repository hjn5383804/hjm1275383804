x=3.14159269999

print("%.3f"%x)


# for i in range(1,10):
#     for j in range(1,i+1):
#         print("{}*{}={} ".format(i,j,i*j),end='')
#     print('')


def dog1(n,a,**kwargs):

    print(n,a,kwargs)

dog1('bbb',1,**{"junk":"food"})
dog1('bbb',1,key='www.baidu,com')
a=lambda x,y:x+y
print(a(2,2))
print(a(4,6))


students = [{'name': 'John', 'age': 20}, {'name': 'Jane', 'age': 22}, {'name': 'Jim', 'age': 21}]
for i in students:
    if i.get('name')=='Jane':
        print(i.get('age'))