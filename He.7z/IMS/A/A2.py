def f2():
    print('2')