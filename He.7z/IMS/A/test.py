from A import *
A1.f1()
A2.f2()
import requests
s = requests.Session()
r = s.get('http://127.0.0.1:8080')
print(r.status_code)