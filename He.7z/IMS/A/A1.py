def f1():
    print('1')