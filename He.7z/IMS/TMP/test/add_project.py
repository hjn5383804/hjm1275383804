import random

#
from UI.WEB.COM.base2 import Base


ims = Base("Chrome", 'http://118.178.252.225')
ims.send_keys('name,account', '18583382064')
ims.send_keys('name,pwd', '123456')
ims.click('xpath,//span[text()="登录"]')
ims.click('xpath,//B[@href="/overview/list"]')
while True:
    try:
        ims.click('xpath,//span[text()="新建项目"]')
        ims.send_keys('name,project_name', "".join(random.choices('qwertyuiopasdfghjklzxcvbnm1234567890', k=10)))
        ims.click('name,net_mode')
        index=random.choice([1,2])
        ims.click('xpath,/html/body/div[3]/div/div[{}]'.format(index))
        ims.click('xpath,//span[text()="确认"]')
    except:
        ims.refresh()