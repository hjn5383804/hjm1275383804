# coding:utf-8

import json
with open('r.txt', encoding="utf8") as json_data:
    x = json.load(json_data)
list_data = x.values()
mac_list = []
for i in list_data:
    for j in i:
        mac=j.get('mac')
        mac_list.append(mac)
print(len(mac_list))
print(len(set(mac_list)))