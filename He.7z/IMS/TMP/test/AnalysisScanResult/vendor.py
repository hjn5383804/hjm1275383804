from UI.WEB.COM import get_file_data
def get_vendor(mac):
    data=get_file_data.GetFileData().get_csv('test.csv')
    for i in data:
        if i[0]==mac:
            print(i[1])
            break
get_vendor('C8:3A:35')
get_vendor('D8:38:0D')
get_vendor('82:9B:20')