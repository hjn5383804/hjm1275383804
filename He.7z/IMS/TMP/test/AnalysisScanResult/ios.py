# coding:gbk
import json

from TMP.test.AnalysisScanResult.frequency import count_2G, count_5G

list_5G_channel = [36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161, 165]


def count_tongpin(channel):
    with open('test.txt', encoding="gbk") as json_data:
        x = json.load(json_data)
    list_data = x.values()
    rssi_list = []
    for i in list_data:
        for j in i:
            if j.get('channel') == channel:
                rssi_list.append(j.get('signal'))
    a = b = c = 0
    for k in rssi_list:
        if k < -60:
            a += 1
        elif -60 <= k <= -40:
            b += 1
        else:
            c += 1
    print(f"С��-60dB������Ϊ:{a}")
    print(f"-60~-40dB������Ϊ:{b}")
    print(f"����-40dB������Ϊ:{c}")
    if rssi_list:
        print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
    if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    print("���ŵ�ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in range(1, 15):
        print(f"{i}�ŵ�")
        count_tongpin(i)
        print('**********************')
    for i in list_5G_channel:
        print(f"{i}�ŵ�")
        count_tongpin(i)
        print('**********************')


def get_tongpin(channel):
    with open('test.txt', encoding="gbk") as json_data:
        x = json.load(json_data)
    list_data = x.values()
    rssi_list = []
    for i in list_data:
        for j in i:
            if j.get('channel') == channel:
                rssi_list.append(j.get('signal'))
    return rssi_list


def count_2G_linpin(channel):
    with open('test.txt', encoding="gbk") as json_data:
        x = json.load(json_data)
    list_data = x.values()
    rssi_list = []
    bandwidth_list = [20, 40]
    for bandwidth in bandwidth_list:
        for ganrao_channel in count_2G(channel, bandwidth):
            for i in list_data:
                for j in i:
                    if j.get('channel') == ganrao_channel and j.get('bandwidth') == bandwidth:
                        rssi_list.append(j.get('signal'))
    print("��Ƶ�����б���",rssi_list)
    print("ͬƵ�����б���",get_tongpin(channel))
    rssi_list += get_tongpin(channel)
    a = b = c = 0
    for k in rssi_list:
        if k < -60:
            a += 1
        elif -60 <= k <= -40:
            b += 1
        else:
            c += 1
    print(f"С��-60dB������Ϊ:{a}")
    print(f"-60~-40dB������Ϊ:{b}")
    print(f"����-40dB������Ϊ:{c}")
    if rssi_list:
        print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
    if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    print("���ŵ���Ƶ+ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in range(1, 15):
        print(f"{i}�ŵ�")
        count_2G_linpin(i)
        print('**********************')


def count_5G_linpin(channel):
    with open('test.txt', encoding="gbk") as json_data:
        x = json.load(json_data)
    list_data = x.values()
    rssi_list = []
    bandwidth_list = [20, 40, 80, 160]
    for bandwidth in bandwidth_list:
        for ganrao_channel in count_5G(channel, bandwidth):
            for i in list_data:
                for j in i:
                    if j.get('channel') == ganrao_channel and j.get('bandwidth') == bandwidth:
                        rssi_list.append(j.get('signal'))
    print("��Ƶ�����б���",rssi_list)
    print("ͬƵ�����б���",get_tongpin(channel))
    rssi_list += get_tongpin(channel)
    a = b = c = 0
    for k in rssi_list:
        if k < -60:
            a += 1
        elif -60 <= k <= -40:
            b += 1
        else:
            c += 1
    print(f"С��-60dB������Ϊ:{a}")
    print(f"-60~-40dB������Ϊ:{b}")
    print(f"����-40dB������Ϊ:{c}")
    if rssi_list:
        print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
    if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    print("���ŵ���Ƶ+ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in list_5G_channel:
        print(f"{i}�ŵ�")
        count_5G_linpin(i)
        print('**********************')
