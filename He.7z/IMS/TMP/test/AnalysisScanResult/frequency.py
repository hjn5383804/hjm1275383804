dict_2G = {
    "1": 2412,
    "2": 2417,
    "3": 2422,
    "4": 2427,
    "5": 2432,
    "6": 2437,
    "7": 2442,
    "8": 2447,
    "9": 2452,
    "10": 2457,
    "11": 2462,
    "12": 2467,
    "13": 2472,
    "14": 2484
}

dict_5G = {"36": 5180,
           "40": 5200,
           "44": 5220,
           "48": 5240,
           "52": 5260,
           "56": 5280,
           "60": 5300,
           "64": 5320,
           "149": 5745,
           "153": 5765,
           "157": 5785,
           "161": 5805,
           "165": 5825
           }



list_5G_channel = [36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161, 165]


def count_2G(channel, bandwidth):
    global offset
    channel = str(channel)
    frequency = dict_2G.get(channel)
    offset=bandwidth/2
    start_frequency = frequency - offset
    end_frequency = frequency + offset
    list_channel = []
    for i in dict_2G.keys():
        if end_frequency >= dict_2G.get(i) >= start_frequency and i != channel:
            list_channel.append(int(i))
    return list_channel


def count_5G(channel, bandwidth):
    global offset
    channel = str(channel)
    frequency = dict_5G.get(channel)
    offset=bandwidth/2
    start_frequency = frequency - offset
    end_frequency = frequency + offset
    list_channel = []
    for i in dict_5G.keys():
        if end_frequency >= dict_5G.get(i) >= start_frequency and i != channel:
            list_channel.append(int(i))
    return list_channel


if __name__ == '__main__':
    for channel in range(1, 15):
        print(channel,"信道邻频干扰信道","20MHz:", count_2G(channel, 20),"40MHz:", count_2G(channel, 40))
    for channel in list_5G_channel:
        print(channel,"信道邻频干扰信道","20MHz:",count_5G(channel,20),"40MHz:",count_5G(channel,40),"80MHz:",count_5G(channel,80),"160MHz:",count_5G(channel,160))

