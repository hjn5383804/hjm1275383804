# coding:gbk
from TMP.test.AnalysisScanResult.frequency import count_2G, count_5G
import re

fre_dict = {
    "1": 2412,
    "2": 2417,
    "3": 2422,
    "4": 2427,
    "5": 2432,
    "6": 2437,
    "7": 2442,
    "8": 2447,
    "9": 2452,
    "10": 2457,
    "11": 2462,
    "12": 2467,
    "13": 2472,
    "36": 5180,
    "40": 5200,
    "44": 5220,
    "48": 5240,
    "52": 5260,
    "56": 5280,
    "60": 5300,
    "64": 5320,
    "149": 5745,
    "153": 5765,
    "157": 5785,
    "161": 5805,
    "165": 5825
}

list_5G_channel = [36, 40, 44, 48, 52, 56, 60, 64, 149, 153, 157, 161, 165]
dict_bandwidth = {
    0: "20",
    1: "40",
    2: "80",
    3: "160",
}


def get_channel_by_fre(fre):
    for i in fre_dict.keys():
        if fre_dict.get(i) == fre:
            return int(i)


def get_bandwidth(index):
    return int(dict_bandwidth.get(index))


def count_tongpin(channel):
    with open('log.txt', 'r', encoding='utf8') as f1:
        data = f1.read()
        x = re.findall('scanresult:(.+?)\n', data)
        rssi_list = []
        for i in x:
            fre = int(re.findall('frequency: (.+?),', i)[0])
            get_channel = get_channel_by_fre(fre)
            if get_channel == channel:
                rssi = re.findall('level: (.+?),', i)[0]
                rssi_list.append(int(rssi)+10)
        print(rssi_list)
    a = b = c = 0
    for k in rssi_list:
        if k < -60:
            a += 1
        elif -60 <= k <= -40:
            b += 1
        else:
            c += 1
    print(f"С��-60dB������Ϊ:{a}")
    print(f"-60~-40dB������Ϊ:{b}")
    print(f"����-40dB������Ϊ:{c}")
    if rssi_list:
        print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
    if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
        print(f"{channel}�ŵ���ɫΪ��ɫ")
    print("���ŵ�ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in range(1, 15):
        print(f"{i}�ŵ�")
        count_tongpin(i)
        print('**********************')
    for i in list_5G_channel:
        print(f"{i}�ŵ�")
        count_tongpin(i)
        print('**********************')


def get_tongpin(channel):
    with open('log.txt', 'r', encoding='utf8') as f1:
        data = f1.read()
        x = re.findall('scanresult:(.+?)\n', data)
        rssi_list = []
        for i in x:
            fre = int(re.findall('frequency: (.+?),', i)[0])
            get_channel = get_channel_by_fre(fre)
            if get_channel == channel:
                rssi = re.findall('level: (.+?),', i)[0]
                rssi_list.append(int(rssi)+10)
    return rssi_list


def count_2g_linpin(channel):
    with open('log.txt', 'r', encoding='utf8') as f1:
        data = f1.read()
        x = re.findall('scanresult:(.+?)\n', data)
        rssi_list = []
        bandwidth_list = [20, 40]
        for bandwidth in bandwidth_list:
            for ganrao_channel in count_2G(channel, bandwidth):
                for i in x:
                    # ��ȡ�ŵ�
                    fre = int(re.findall('frequency: (.+?),', i)[0])
                    channel_data = get_channel_by_fre(fre)
                    # ��ȡƵ��
                    index = re.findall('ChannelBandwidth: (.+?),', i)[0]
                    bandwidth_data = get_bandwidth(int(index))
                    if channel_data == ganrao_channel and bandwidth_data == bandwidth:
                        rssi = re.findall('level: (.+?),', i)[0]
                        rssi_list.append(int(rssi)+10)
        print("��Ƶ�����б���", rssi_list)
        print("ͬƵ�����б���", get_tongpin(channel))
        rssi_list += get_tongpin(channel)
        a = b = c = 0
        for k in rssi_list:
            if k < -60:
                a += 1
            elif -60 <= k <= -40:
                b += 1
            else:
                c += 1
        print(f"С��-60dB������Ϊ:{a}")
        print(f"-60~-40dB������Ϊ:{b}")
        print(f"����-40dB������Ϊ:{c}")
        if rssi_list:
            print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
        if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        print("���ŵ���Ƶ+ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in range(1, 15):
        print(f"{i}�ŵ�")
        count_2g_linpin(i)
        print('**********************')


def count_5g_linpin(channel):
    with open('log.txt', 'r', encoding='utf8') as f1:
        data = f1.read()
        x = re.findall('scanresult:(.+?)\n', data)
        rssi_list = []
        bandwidth_list = [20, 40, 80, 160]
        for bandwidth in bandwidth_list:
            for ganrao_channel in count_5G(channel, bandwidth):
                for i in x:
                    # ��ȡ�ŵ�
                    fre = int(re.findall('frequency: (.+?),', i)[0])
                    channel_data = get_channel_by_fre(fre)
                    # ��ȡƵ��
                    index = re.findall('ChannelBandwidth: (.+?),', i)[0]
                    bandwidth_data = get_bandwidth(int(index))
                    if channel_data == ganrao_channel and bandwidth_data == bandwidth:
                        rssi = re.findall('level: (.+?),', i)[0]
                        rssi_list.append(int(rssi)+10)
        print("��Ƶ�����б���", rssi_list)
        print("ͬƵ�����б���", get_tongpin(channel))
        rssi_list += get_tongpin(channel)
        a = b = c = 0
        for k in rssi_list:
            if k < -60:
                a += 1
            elif -60 <= k <= -40:
                b += 1
            else:
                c += 1
        print(f"С��-60dB������Ϊ:{a}")
        print(f"-60~-40dB������Ϊ:{b}")
        print(f"����-40dB������Ϊ:{c}")
        if rssi_list:
            print("��ǰ�ŵ�������ǿ��Ϊ��", max(rssi_list))
        if a > 50 or b > 18 or c > 9 or (a > 20 and b > 9 and c > 4):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        elif 50 >= a >= 20 or 18 >= b >= 9 or 9 >= c >= 5 or (20 >= a >= 10 and 9 >= b >= 5 and 5 >= c >= 3):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        elif 20 >= a >= 10 or 9 >= b >= 1 or 5 >= c >= 1 or (10 >= a >= 1 and 5 >= b >= 1 and 3 >= c >= 1):
            print(f"{channel}�ŵ���ɫΪ��ɫ")
        print("���ŵ���Ƶ+ͬƵ��������Ϊ{}".format(len(rssi_list)))


if __name__ == '__main__':
    for i in list_5G_channel:
        print(f"{i}�ŵ�")
        count_5g_linpin(i)
        print('**********************')


