import json

import requests

#
'''
application/x-www-form-urlencoded
'''

data = {
    "user[login]": "账号",
    "user[password]": "密码",
    "user[remember_me]": 0,
    "commit": "登录"
}
headers = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8"
}
url = "https://testerhome.com/account/sign_in"

# 编码格式为application/x-www-form-urlencoded;charset=UTF-8，使用data参数，参数值为dict，
res = requests.post(url=url, headers=headers, data=data)
print(res.text)

'''
请求头的content-type为multipart/form-data
"""表示细分领域的文件类型的种类"""
'''
# 用于自动组装multipart/formdata消息体boundary
from requests_toolbelt.multipart.encoder import MultipartEncoder


def post_mulitpart_form_data():
    url = ''
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36",
        "content-type": "multipart/form-data; boundary=----WebKitFormBoundary4aA3ZrkOVwUIvmx0"
    }

    multipart_encoder = MultipartEncoder(
        fields={
            "id": "WU_FILE_0",
            "name": "app-test.apk",
            "type": "application/octet-stream",
            "lastModifiedDate": "2019/10/16",
            "filename": "app-test.apk",
            "Content-Type": "application/octet-stream",
            "file": ("app-test.apk", open(r'D:\xxxx.apk', 'rb'), 'application/octet-stream')
        },
        boundary='-----------------------------2385610611750'
    )

    result = requests.post(url, headers=headers, data=multipart_encoder)


import requests
import json

'''
请求头的content-type为application/json
'''

headers = {"Content-Type": "application/json;charset=utf8"}
url = "http://127.0.0.1:5000/login"
params = {
    "username": "lilei",
    "password": "123456"
}

# 这里使用json参数，即json=_data
res = requests.post(url=url, headers=headers, json=params).text
# 当然还可以使用data参数，但需先将_data转换为json格式，即data=json.dumps(_data)
# json.dumps()将dict格式转换成json格式
res1 = requests.post(url=url, headers=headers, data=json.dumps(params)).text
print(res1)


'''
请求头的content-type为text/xml
'''

def post_text_xml():
    headers = {"Content-Type": "text/xml"}
    url = "http://httpbin.org/post"

    body = '<?xml version="1.0" encoding = "UTF-8"?>' \
           '<COM>' \
           '<REQ name="给你一页白纸">' \
           '<USER_ID></USER_ID>' \
           '<COMMODITY_ID>111111</COMMODITY_ID>' \
           '<SESSION_ID>asdfghjklfr0123</SESSION_ID>' \
           '</REQ>' \
           '</COM>'

    res = requests.post(url=url, headers=headers, data=body.encode("utf-8")).text
    print(res)


s=requests.Session()
s2=requests.session()


if __name__ == '__main__':
    post_text_xml()