# import uuid
# def a_method():
#     print("I am a_pkg!")
#
#
#
# def conut_len(rssi):
#     if -100<rssi<-20:
#         return "{}%".format((-100-rssi)/-80*100)
#     elif rssi<=-100:
#         return '100%'
#     elif rssi>=-20:
#         return '1%'
#
# print(conut_len(-45))
#
#
#
# print('\a')
# print(int('0011',base=16))
#
#
# a=0b10110
# b=0b00111
# print(a&b)
# print(a|b)
# print(bin(a&b))
#
# print(255&192)
# print(0&100)
#
# x={"a":1,"b":2}
# y=(x,)*10
# print(y)
# x=uuid.uuid1()
# print(x)


x=1
y=repr(x)
print(y)
print(type(y))