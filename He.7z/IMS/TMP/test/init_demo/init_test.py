from TMP.test.init_demo.a_pkg import *
