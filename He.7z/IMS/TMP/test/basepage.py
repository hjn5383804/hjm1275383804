
from selenium import webdriver
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait



class BasePage():
    """通用的页面操作类，任何web网页都可以使用
    locator = ('xpath', '//*...')
    locator = ('id', 'kw')
    找到这个元素， 判断元素是否可以被操作，如果可以被操作，再执行
    """
    def __init__(self, driver):
        self.driver = driver

    def wait_page_loaded(self, url, timeout=10):
        """等待某个页面加载"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        wait.until(expected_conditions.url_contains(url))

    def wait_element_clickable(self, locator, timeout=10):
        """等待某个元素可以被点击"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        el = wait.until(expected_conditions.element_to_be_clickable(locator))
        return el

    def wait_element_visible(self, locator, timeout=10):
        """等待元素可见"""
        wait = WebDriverWait(self.driver, timeout=timeout)
        el = wait.until(expected_conditions.visibility_of_element_located(locator))
        return el

    def click(self, locator, timeout=10):
        """点击"""
        el = self.wait_element_clickable(locator, timeout=timeout)
        el.click()

    def send_keys(self, locator, words, timeout=10):
        """输入"""
        el = self.wait_element_visible(locator, timeout=timeout)
        el.send_keys(words)

    def double_click(self, locator):
        """双击"""
        action = ActionChains(self.driver)
        el = self.wait_element_clickable(locator)
        action.double_click(el).perform()

    def drag_and_drop(self, locator1, locator2):
        """拖动"""
        action = ActionChains(self.driver)
        el1 = self.wait_element_clickable(locator1)
        el2 = self.wait_element_clickable(locator2)
        action.drag_and_drop(el1, el2).perform()

    def enter(self):
        """回车"""
        action = ActionChains(self.driver)
        action.send_keys(Keys.ENTER).perform()

    def switch_to_frame(self, locator):
        """切换 iframe"""
        el = self.wait_element_visible(locator)
        self.driver.switch_to.frame(el)

    def send_file(self, locator, file_path):
        """发送文件"""
        el = self.wait_element_visible(locator)
        el.send_keys(file_path)

    def select(self, locator1, locator2):
        """下拉选择"""
        self.click(locator1)
        self.click(locator2)

    # 双击， 悬停， 拖动， 右击
    # 回车，  copy
    # iframe，  window, alert
    # 下拉框操作， 多选， 单选
    # 文件上传
    # 修改元素属性（js)
    #

T=BasePage(webdriver.chrome)
T.wait_page_loaded('http://192.168.1.132/login.html')