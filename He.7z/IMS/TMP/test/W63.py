import requests
s=requests.session()
headers={
"Accept": "application/json, text/plain, */*",
"Accept-Encoding": "gzip, deflate",
"Accept-Language": "zh-CN,zh;q=0.9",
"AccessType": "web",
"Connection": "keep-alive",
"Content-Type": "application/json",
"Cookie": "72de15a8da2c1ca73a4c7081b6df86e0",
"Host": "118.178.252.225",
"IMSRequestOrigin": "http://118.178.252.225/overview/list",
"Origin": "http://118.178.252.225",
"Token": "72de15a8da2c1ca73a4c7081b6df86e0",
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
"version": "v1.4.0"
}
url="http://ims.test.ip-com.com.cn/RadioConfig/SignalAnalysisScan"

body={
"mesh_id":"",
"sn":"IPCOM1000000000007762"
}

re=s.post(url=url,headers=headers,data=body)
print(re.content)