import logging
import sys
import telnetlib
import time
from datetime import datetime
import requests


def telnet(command, DUT_ip, log_path):
    """命令、设备IP、日志保存路径"""

    session = requests.Session()
    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
        "Origin": "http://{}".format(DUT_ip),
        "Connection": "keep-alive",
    }
    params_login = {
        "sysLogin": {
            "username": "admin",
            "password": "YWRtaW4=",
            "logoff": "false",
        }
    }
    print("日志保存路径为：{}".format(log_path))
    resp = session.post('http://{}/goform/modules'.format(DUT_ip), json=params_login, headers=header, timeout=3)
    resp_text = str(resp.text)
    exp = '{"sysLogin":{"userType":"admin","Login":true,"logoff":false}}'
    assert exp == resp_text
    print("初始化登录成功")
    # 打开telnet接口
    session.get('http://{}/goform/telnet'.format(DUT_ip))
    tn = telnetlib.Telnet()
    try:
        tn.open(host='{}'.format(DUT_ip), port=23, timeout=3)
    except:
        logging.warning('网络连接失败')
        return False
    # 账号
    tn.read_until(b'login: ', timeout=3)
    tn.write("root".encode('ascii') + b'\n')
    # 密码
    tn.read_until(b'Password: ', timeout=3)
    tn.write("Fireitup".encode('ascii') + b'\n')
    while True:
        f = open(r"{}".format(log_path), "B+")
        sys.stdout = f
        tn.write(command.encode('utf-8') + b'\n')
        time.sleep(2)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8', 'ignore')
        tt = datetime.now()
        T = str(tt)[0:19]
        print(T, r, end="")
        time.sleep(60)


telnet("cat /proc/meminfo", "192.168.3.116", 'E://W64_2.log')
