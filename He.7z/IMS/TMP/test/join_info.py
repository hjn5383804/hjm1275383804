# -*- coding: UTF-8 -*-
import datetime

import requests
from time import sleep
import random
from TMP.test.W36_login import switch_to_dict
from TMP.test.W36_telnet import telnet_36



def davece_join(ip):
    # telnet修改设备mac

    # 登录
    login_URL = 'http://{}/login/Auth'.format(ip)
    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
        "Connection": "keep-alive",
        "Origin": "http://192.168.2.165",
        "Referer": "http://192.168.2.165/cloud_manage.asp?version=1639551819"
    }
    login_data = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
    login_params = switch_to_dict(login_data)
    s = requests.Session()
    res = s.post(url=login_URL, data=login_params, headers=header, timeout=3)
    assert 'version=' in res.text
    print("登录成功")
    s.get('http://{}/goform/telnet'.format(ip))
    list_mac = []
    mac_A = "D8:38:0D"
    for i in range(3):
        list_mac.append(':')
        for j in range(2):
            data = random.choice('ABCDEF1234567890')
            list_mac.append(data)
    mac_B = "".join(list_mac)
    mac = (mac_A + mac_B)
    print("本次生成的mac为：{}".format(mac))
    cmd = 'ifconfig eth0 hw ether {} && ifconfig br0 hw ether {}'.format(mac, mac)
    telnet_36(cmd, ip)
    sleep(3)
    # 输入唯一码并开启云管：
    ucloud_data_off = 'GO=cloud_manage.asp&ucloudEn=false&ucloudMode=1&ucloudId=3c2561faa90c021798a81bd8fedc1e5e&ucMsgReport=false&radio=2.4G'
    ucloud_data_on = 'GO=cloud_manage.asp&ucloudEn=true&ucloudMode=1&ucloudId=3c2561faa90c021798a81bd8fedc1e5e&ucMsgReport=true&radio=2.4G'
    ucloud_URL = 'http://{}/goform/ucloudSet'.format(ip)
    ucloud_params_on = switch_to_dict(ucloud_data_on)
    ucloud_params_off = switch_to_dict(ucloud_data_off)
    res1 = s.post(url=ucloud_URL, data=ucloud_params_off, headers=header, timeout=3)
    # print(res.text)
    assert "ok" in res1.text
    t = str(datetime.datetime.now())[0:19]
    print("W36AP关闭云管理成功", t)
    sleep(15)
    res2 = s.post(url=ucloud_URL, data=ucloud_params_on, headers=header, timeout=3)
    # print(res.text)
    assert "ok" in res2.text
    t = str(datetime.datetime.now())[0:19]
    print("W36AP开启云管理成功", t)
    # sleep(45)


if __name__ == '__main__':
    while True:
        try:
            davece_join('192.168.1.161')
        except:
            pass


