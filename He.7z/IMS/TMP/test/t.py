import random
import re


# def re_phone_num(phone_num):
#     result = re.match(r'^1[34578]\d{9}$', phone_num).group(0)
#     assert phone_num == result
#     return True
#
#
# print(re_phone_num('18583382064'))
# print(re_phone_num('15583382064'))
# print(re_phone_num('13583382064'))
# print(re_phone_num('17583382064'))
# print(re_phone_num('16583382064'))
import time


# def str_ip(ip):
#     ip = str(ip)
#     result = ip.split(".")
#     assert 1 <= int(result[0]) <= 223 and 1 <= int(result[1]) <= 255 and 1 <= int(result[2]) <= 255 and 1 <= int(
#         result[3]) <= 254
#     return True


# print(str_ip('192.168.1.1'))
# print(time.process_time())


def y(a,b,*args):
    if args:
        print(args)
        return a**b
print(y(5,6,7,8,9))


# key = 'v123.34.56345673111111'
# print(len(key))
# print(key[0:16])

