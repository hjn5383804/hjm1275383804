# -*- coding: UTF-8 -*-
import datetime

import requests
from time import sleep
import random

from IMS.TMP.test.W36_login import switch_to_dict

from IMS.TMP.test.W36_telnet import telnet_36



def ch_mac(ip):
    # telnet修改设备mac

    # 登录
    login_URL = 'http://{}/login/Auth'.format(ip)
    header = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36",
        "Connection": "keep-alive",
        "Origin": "http://192.168.2.165",
        "Referer": "http://192.168.2.165/cloud_manage.asp?version=1639551819"
    }
    login_data = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
    login_params = switch_to_dict(login_data)
    s = requests.Session()
    res = s.post(url=login_URL, data=login_params, headers=header, timeout=3)
    assert 'version=' in res.text
    print("登录成功")
    s.get('http://{}/goform/telnet'.format(ip))
    list_mac = []
    mac_A = "00:00:01"
    for i in range(3):
        list_mac.append(':')
        for j in range(2):
            data = random.choice('ABCDEF1234567890')
            list_mac.append(data)
    mac = (mac_A +  "".join(list_mac))
    print("本次生成的mac为：{}".format(mac))
    cmd = 'ifconfig br0 hw ether {} && ifconfig br0 hw ether {}'.format(mac, mac)
    telnet_36(cmd, ip)
    sleep(100)



ch_mac('192.168.3.164')