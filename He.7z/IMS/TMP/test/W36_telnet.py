
import logging
import telnetlib
import time
import requests
class Telnet_W36():
    def __init__(self,ip):
        self.ip=ip

    def switch_to_dict(self,str):
        global index
        list_i = []
        dict_i = {}
        temp = 'TEMP'
        str = str.replace('%3B', ";")
        str = str.split("&")
        for i in str:
            if i.count("=") > 1:
                # 获取第一个"="的位置
                index = i.find("=")
                x = i.replace(i[index], temp, 1)
                i = x.split(temp)
            else:
                i = i.split("=")
            list_i.append(i)
        for j in list_i:
            dict_j = {j[0]: j[1]}
            dict_i.update(dict_j)
        return dict_i
    def telnet_36(self,command):
        """适用于W36AP
        command:命令
        ip：AP的地址
        """
        login_URL = 'http://{}/login/Auth'.format(self.ip)
        login_params = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
        login_params = self.switch_to_dict(login_params)
        global init_flag
        #先尝试telnet连接，获取连接结果
        tn = telnetlib.Telnet()
        try:
            tn.open(host='{}'.format(self.ip),port=23,timeout=3)
            init_flag = True
        except:
            logging.warning('网络连接失败')
            init_flag=False
        #失败则打开23端口
        if init_flag==False:
            s = requests.Session()
            for i in range(3):
                s.post(url=login_URL, data=login_params, timeout=(5,10))
                res=s.get('http://{}/goform/telnet'.format(self.ip))
                if "load telnetd success" in res.text:
                    print('DUT telnet端口成功打开')
                    s.close()
                    break
        tn.open(host='{}'.format(self.ip), port=23, timeout=3)
        tn.read_until(b'login: ', timeout=3)
        tn.write("root".encode('ascii') + b'\n')
        # 密码浮标
        tn.read_until(b'Password: ', timeout=3)
        tn.write("Fireitup".encode('ascii') + b'\n')
        tn.write(command.encode('utf-8') + b'\n')
        time.sleep(0.5)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8', 'ignore').replace(command, "").replace('~ # ', "").replace('\r\n',"",3)
        # 退出telnet
        tn.write(b"exit")
        tn.close()
        return r

x=Telnet_W36('192.168.0.167')
print("2.4G开关：",x.telnet_36('cfm get wl2g.public.enable'))
print("2.4G国家码：",x.telnet_36('cfm get wl2g.public.country_code'))
print("2.4G信道：",x.telnet_36('cfm get wl2g.public.channel'))
print("2.4G功率：",x.telnet_36('cfm get wl2g.public.current_power'))
print("5G开关：",x.telnet_36('cfm get wl5g.public.enable'))
print("5G国家码：",x.telnet_36('cfm get wl5g.public.country_code'))
print("5G信道：",x.telnet_36('cfm get wl5g.public.channel'))
print("5G功率：",x.telnet_36('cfm get wl5g.public.current_power'))

