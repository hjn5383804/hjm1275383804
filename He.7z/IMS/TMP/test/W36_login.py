import requests


def switch_to_dict(str):
    global index
    list_i = []
    dict_i = {}
    temp = 'TEMP'
    str = str.replace('%3B', ";")
    str = str.split("&")
    for i in str:
        if i.count("=") > 1:
            # 获取第一个"="的位置
            index = i.find("=")
            x = i.replace(i[index], temp, 1)
            i = x.split(temp)
        else:
            i = i.split("=")
        list_i.append(i)
    for j in list_i:
        dict_j = {j[0]: j[1]}
        dict_i.update(dict_j)
    return dict_i


s = requests.Session()
login_URL = 'http://{}/login/Auth'.format('192.168.0.167')
login_params = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
login_params = switch_to_dict(login_params)
s.post(url=login_URL, data=login_params, timeout=(5, 10))
res =s.get('http://{}/goform/telnet'.format('192.168.0.167'))
print(res.text)