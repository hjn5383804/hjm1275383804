import logging
import telnetlib
import time
import requests
class ReadTelnet(object):

    def telnet_W83AP(self,command, ip,password="YWRtaW4="):
        """适用于W83AP、W63AP、W64AP、W80AP
        command:命令
        ip：AP的地址
        """
        global init_flag
        #先尝试telnet连接，获取连接结果
        tn = telnetlib.Telnet()
        try:
            tn.open(host='{}'.format(ip),port=23,timeout=3)
            init_flag = True
        except:
            logging.warning('网络连接失败')
            init_flag=False
        #失败则打开23端口
        if init_flag==False:
            session = requests.Session()
            params_login = {
                "sysLogin": {
                    "username": "admin",
                    "password": password,
                    "logoff": "false",
                }
            }
            for i in range(3):
                resp = session.post('http://{}/goform/modules'.format(ip), json=params_login, timeout=10)
                resp_text = str(resp.text)
                exp = '{"sysLogin":{"userType":"admin","Login":true,"logoff":false}}'
                if exp == resp_text:
                    session.get('http://{}/goform/telnet'.format(ip))
                    print("DUT 23端口初始化成功")
                    break
        #账号
        tn.open(host='{}'.format(ip), port=23, timeout=3)
        tn.read_until(b'login: ',timeout=3)
        tn.write("root".encode('ascii') + b'\n')
        #密码
        tn.read_until(b'Password: ',timeout=3)
        tn.write("Fireitup".encode('ascii') + b'\n')
        tn.write(command.encode('utf-8')+b'\n')
        time.sleep(2)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8','ignore').replace(command,"").replace('root@W83AP:~#',"").replace('BusyBox v1.30.1 () built-in shell (ash)',"").replace('\r\n',"",6)
        # 退出telnet
        tn.write(b"exit")
        return r


    def switch_to_dict(self,str):
        """将get传参的请求数据如：'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin',转换为字典"""
        global index
        list_i = []
        dict_i = {}
        temp = 'THIS IS A TEMP'
        #%3B解析出来就是分号，不用传登录时的时间戳，也是可以登录成功的
        str = str.replace('%3B', ";")
        str = str.split("&")
        for i in str:
            if i.count("=") > 1:
                # 获取第一个"="的位置
                index = i.find("=")
                x = i.replace(i[index], temp, 1)
                i = x.split(temp)
            else:
                i = i.split("=")
            list_i.append(i)
        for j in list_i:
            dict_j = {j[0]: j[1]}
            dict_i.update(dict_j)
        return dict_i
    def telnet_W36AP(self,command,ip):
        """适用于W36AP
        command:命令
        ip：AP的地址
        """
        login_URL = 'http://{}/login/Auth'.format(ip)
        login_params = 'usertype=admin&password=YWRtaW4=&time=2021%3B12%3B21%3B9%3B14%3B44&username=admin'
        login_params = self.switch_to_dict(login_params)
        global init_flag
        #先尝试telnet连接，获取连接结果
        tn = telnetlib.Telnet()
        try:
            tn.open(host='{}'.format(ip),port=23,timeout=3)
            init_flag = True
        except:
            logging.warning('网络连接失败')
            init_flag=False
        #失败则打开23端口
        if init_flag==False:
            s = requests.Session()
            for i in range(3):
                s.post(url=login_URL, data=login_params, timeout=(5,10))
                res=s.get('http://{}/goform/telnet'.format(ip))
                if "load telnetd success" in res.text:
                    print('DUT telnet端口成功打开')
                    s.close()
                    break
        tn.open(host='{}'.format(ip), port=23, timeout=3)
        tn.read_until(b'login: ', timeout=3)
        tn.write("root".encode('ascii') + b'\n')
        # 密码浮标
        tn.read_until(b'Password: ', timeout=3)
        tn.write("Fireitup".encode('ascii') + b'\n')
        tn.write(command.encode('utf-8') + b'\n')
        time.sleep(2)
        # 获取命令结果
        r = tn.read_very_eager().decode('utf-8', 'ignore').replace(command, "").replace('~ # ', "").replace('\r\n',"")
        # 退出telnet
        tn.write(b"exit")
        tn.close()
        return r

x=ReadTelnet().telnet_W36AP('cfm get wl2g.public.channel','192.168.0.167')
print(x)
print(len(x))