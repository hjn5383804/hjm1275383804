# list1 = ["B", "B"]
# num=0
# for i in range(100):
#     for j in list1:
#         num+=1
#         print(f"第{num}次升级，选择的文件为{j}")




# list1=[1]
# if list1:
#     print(1)
# else:
#     print(2)