import traceback

from IMS.UI.WEB.COM.base2 import Base


d = Base("Chrome", 'http://192.168.3.190')
d.send_keys('id,username', 'admin')
d.send_keys('id,password', 'admin')
d.click('id,save')
d.click('id,wireless')
d.click('id,2.4G_radio_setting@ap')
d.sleep(1)
d.click('xpath,//span[text()="5GHz射频设置"]')
while True:
    try:
        d.sleep(5)
        d.click('id,wifiEn')
        d.click('xpath,//input[@value="保存"]')
        d.sleep(25)
    except Exception as e:
        print(repr(e))
        print(traceback.format_exc())

