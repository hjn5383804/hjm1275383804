import re


data= '<input type="hidden" name="userSession" value="12345678"/>'
print(re.findall('<input type="hidden" name="userSession" value="(.+?)"/>',data))
