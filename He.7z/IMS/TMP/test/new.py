from IMS.TMP.test.inti_demo2.a import *
