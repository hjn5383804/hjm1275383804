for i in range(100):
    print(i if i%2==0 else '\n')



