#coding=utf-8

import random

list1=[1,2,34,5]
print(sum(list(range(101))))
print(sum(list1))
random.shuffle(list1)
print(list1)

##字符串

str1="abcdefg"

print(str1[::-1])

str2="12345678"
print(str2[::-1])
