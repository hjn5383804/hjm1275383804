# def B(B,b,c,d=1):
#     print(B)
#     print(b)
#     print(c)
#     print(d)
# B(1,2,3)
# B(1,2,3,4)
def b(B,b,c,*args):
    print(B)
    print(b)
    print(c)
    print(args)

b(1,2,3,4,5,6,7,8,9,{"B":123},[123,1])
# *args接收超出的非键值对参数,**kwargs接收超出的键值对参数(x=B)
# def c(B,b,c,*args,**kwargs):
#     print(B)
#     print(b)
#     print(c)
#     print(args)
#     print(kwargs)
# c(1,2,3,4,5,6,7,8,9,[123,1],{"B":123},x=123,y=888)
# x=(1,2,3,4,[5,6],7)
# print(*x)
# y={"1":2,"3":4}
# def e(B,b,c,*args,**kwargs):
#     print(B)
#     print(b)
#     print(c)
#     print(args)
#     print(kwargs)
# e(1,2,3,45,55,66,**y)
# B=(lambda x,y:x+y)(4,22)
# print(B)
#
# B=lambda x,y:x+y
# print(B(10,20))

# def f(n):
#     n=n
#     if n==1:
#         return 1
#     return n*f(n-1)
# print(f(5000))
# import time
# from functools import reduce
# def fun(n):
#     """
#   reduce() 函数会对参数序列中元素进行累积
#  需传入： 函数、可迭代对象
#     """
#     list1=iter(list(range(1,n+1)))
#     result2 = reduce((lambda x, y: x + y), list1)
#     print(result2)
#     print(time.process_time())
# fun(100)
# import pip
# print(pip.__version__)
