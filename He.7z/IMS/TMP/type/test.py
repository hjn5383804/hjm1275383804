# x=bool()
# print(x)

# class B():
#     print('B')
#
# class B(B):
#
#     X=B()
# print(isinstance(B(),B))

# import re
# tel='13112341234'
#
# ret = re.match(r"^1[35678]\d{9}$", tel)

import random


def test(x):
    for i in range(x):
        y = random.randint(1, 10)
        yield y


x = test(5)
for j in x:
    print(j)
