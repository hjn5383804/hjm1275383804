#coding=gbk

#˽�з���
# class B:
#     def _a(self):
#         print(1)
#     def b(self):
#         self._a()
#         print(2)
# B().b()

#��д
class aa:
    def __init__(self):
        print(1)
    def a(self):
        print(2)
class bb(aa):
    def __init__(self):
        print(3)
        aa.__init__(self)
    def a(self):
        print(4)
bb().a()


#super(ȡ����д)
class aa:
    def __init__(self):
        print(1)
    def a(self):
        print(2)
class bb(aa):
    def __init__(self):
        print(3)
        aa.__init__(self)
    def a(self):
        print(4)
    def super_a(self):
        super().a()
bb().super_a()



#��̬����
# class aa:
#     def __init__(self):
#         print(1)
#
#     @staticmethod
#     def B():
#         print(2)
# aa.B()
#�����������
# class Vector:
#     def __init__(self, B, b):
#         self.B = B
#         self.b = b
#
#     def __str__(self):
#         return 'Vector (%d, %d)' % (self.B, self.b)
#
#     def __add__(self, other):
#         return Vector(self.B + other.B, self.b + other.b)
#
# v1 = Vector(2, 10)
# v2 = Vector(5, -2)
# v3 = Vector(5, -2)
# print(v1+v2+v3)

