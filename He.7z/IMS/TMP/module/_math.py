# #与运算
# a = 0b1000
# b = 0b1010
# print(a&b)
# print(bin(a&b))
# #或运算
# a = 0b1000
# b = 0b1010
# print(a|b)
# print(bin(a|b))
#
# #非运算: 加1取反
# print(bin(~a))
# print(~a)
# print(a)
#
# print(complex(1, 2))
# print(complex(1))  # 数字
# print(complex("1"))  # 当做字符串处理
# print(complex("1+2j"))

str1 = "Runoob example....wow!!!"
str2 = "exam"
print(str1.find(str2))


def a():
    pass
a()