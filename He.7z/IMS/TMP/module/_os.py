import os
#
# 获取当前工作目录，即当前python脚本工作的目录路径
# print(os.getcwd())
#
#
# # 改变当前脚本工作目录；linux cd命令
# os.chdir("D:/")


# #在当前目录生成dirname1/dirname2层级目录
# os.makedirs('dir1/dir2')


# #在D盘生成dirname1/dirname2的层级目录
# os.chdir("D:/")
# os.makedirs('dir1/dir2')


#递归删除目录，先判断dir2是否为空，若为空删除dir2，再继续判断dir1是否为空。。。
# os.removedirs('dir1/dir2')


#生成单级目录
# os.mkdir('dir1')


#删除单级目录
# os.rmdir('dir1')

#列表形式返回当前目录所有文件和子目录，包括隐藏文件
# print(os.listdir())


#删除文件
# os.remove('111')

# 重命名文件 / 目录，"oldname","newname"
# os.rename("111.txt","222.html")
# os.rename('123','444')


# 获取文件/目录详细信息
print(os.stat('TEST_DATA/B.csv'))



# 操作平台
# print(os.name)

#环境变量
# print(os.environ)

#执行操作系统命令
#
# os.system('ipconfig/release')
# os.system('ipconfig/renew')


# 判断name是不是一个目录，name不是目录就返回false
# print(os.path.isfile('E://cheack_free.log'))


# 判断name是不是一个文件，不存在返回false
# print(os.path.isdir('E://cheack_free.log'))
