import datetime
import time

print(datetime.datetime.now()) #返回最精确的时间

print(datetime.date.fromtimestamp(time.time()) ) # 时间戳直接转成日期格式（年-月-日）


print(datetime.datetime.now() + datetime.timedelta(3)) #不指定实参默认为天：当前时间+3天

print(datetime.datetime.now() + datetime.timedelta(-3)) #当前时间-3天

print(datetime.datetime.now() + datetime.timedelta(hours=3)) #当前时间+3小时

print(datetime.datetime.now() + datetime.timedelta(minutes=30)) #当前时间+30分


print(str(datetime.datetime.now())[0:19])#字符串截取时间只精确到秒