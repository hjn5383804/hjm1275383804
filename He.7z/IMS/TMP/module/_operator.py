import operator
B=1
b=2
print(operator.lt(B, b))
operator.le(B, b)
operator.eq(B, b)
operator.ne(B, b)
operator.ge(B, b)
operator.gt(B, b)
operator.__lt__(B, b)
operator.__le__(B, b)
operator.__eq__(B, b)
operator.__ne__(B, b)

print(operator.__ge__(B, b))
print(operator.__gt__(B, b))

