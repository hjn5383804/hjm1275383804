import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 8080))
# msg = input('please input')
msg='hello'
# 防止输入空消息
assert msg is not None

client.send(msg.encode('utf-8'))  # 收发消息一定要二进制，记得编码
client.close()