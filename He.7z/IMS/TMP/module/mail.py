import smtplib
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header


def send_attach_emai(receiver, file_path):
    # 实例化连接对象
    con = smtplib.SMTP_SSL('imap.tenda.cn', 465)
    con.login('hejinmao@tenda.cn', 'Tenda.23lsdj23@')
    # 创建邮件对象
    msg = MIMEMultipart()
    # 设置邮件主题
    subject = Header('测试报告', 'utf-8').encode()
    msg['Subject'] = subject
    # 设置邮件发送者
    msg['From'] = 'hejinmao@tenda.cn <hejinmao@tenda.cn>'
    # 设置邮件接受者
    msg['To'] = receiver

    img_file = open(r'E:/test.jpg', 'rb')
    img_data = img_file.read()
    img_file.close()
    img = MIMEImage(img_data)
    img.add_header('Content-ID', 'img1')  # 给一个content Id 供后面html内容引用
    msg.attach(img)
    content = """
       <html>
         <body>
            <h2>Hello all！</h2>
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;XXX项目第X轮自动化测试已完成，测试结果请查收附件~</p>
            <p>电话：18583382064</p>
            <p>邮箱：hejinmao@tenda.cn</p>
           <img src="cid:img1">
         </body>
       </html>
"""
    html = MIMEText(content, 'html', 'utf-8')
    msg.attach(html)
    # 添加附件
    file1 = MIMEText(open(file_path, encoding='utf-8').read(), 'base64', 'utf-8')
    file1["Content-Disposition"] = 'attachment; filename="result.html"'
    msg.attach(file1)
    con.sendmail('hejinmao@tenda.cn <hejinmao@tenda.cn>', receiver, msg.as_string())
    con.quit()


send_attach_emai('hejinmao@tenda.cn <hejinmao@tenda.cn>;yangyongming@tenda.cn <yangyongming@tenda.cn>', r'E:/report.html')
