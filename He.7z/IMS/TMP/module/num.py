import numpy as np

arr = np.array([1, 2, 3, 4, 5])

# 计算平方根
sqrt_arr = np.sqrt(arr)

# 计算指数
exp_arr = np.exp(arr)

# 计算自然对数
log_arr = np.log(arr)

import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6])

# 将一维数组变为二维数组
reshaped_arr = arr.reshape(2, 3)
print(reshaped_arr)
# 使用-1来自动计算维度
reshaped_arr = arr.reshape(-1, 3)  # 3行，自动计算列数

print(reshaped_arr)
