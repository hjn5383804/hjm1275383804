import time
#强制等待
# time.sleep(1)

#计算处理器运算时间
# i=1
# sum=0
# while i<=100000000:
#     sum=sum+i
#     i=i+1
# print(sum)
# print(time.process_time())

#国际时间
print(time.asctime())

#struct_time对象格式的时间
print(time.localtime())
