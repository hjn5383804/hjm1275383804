import threading, time


def run(n):
    print("task  ", n)
    time.sleep(2)


start_time = time.time()
t1 = threading.Thread(target=run, args=("t1",))
t2 = threading.Thread(target=run, args=("t2",))
# 若不加join，主线程与子线程会并发执行，打印的时间实际是主线程运行的时间
# 加join，主线程会等待子线程结束，再跳到下一个join函数下的子线程
t1.start()
t2.start()
# t1.join()
# t2.join()
print(time.time() - start_time)
