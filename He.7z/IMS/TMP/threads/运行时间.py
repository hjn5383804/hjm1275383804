import threading
from threading import *
import time

n = [1, 2, 3, 4, 5, 6, 7, 8]


class A(threading.Thread):
    def run(self):
        for x in n:
            time.sleep(1)
            print("线程A计算:",x**2)


class B(threading.Thread):
    def run(self):
        for x in n:
            time.sleep(1)
            print("线程B计算:",x**3)


start = time.time()
a = A()
b = B()
a.start()
b.start()
a.join()
b.join()
end = time.time()
print("双线程运行时间",end - start)


start1 = time.time()
for x in n:
    time.sleep(1)
    print("线程A计算:", x ** 2)
for x in n:
    time.sleep(1)
    print("线程B计算:", x ** 3)
end1 = time.time()
print("单线程运行时间",end1 - start1)