import threading
import time
# 子线程会继承父线程中daemon的值，即守护线程开启的子线程仍是守护线程

# def run(n):
#     print('task',n)
#     time.sleep(1)
#     print('3s')
#     time.sleep(1)
#     print('2s')
#     time.sleep(1)
#     print('1s')
#
# if __name__ == '__main__':
#     t=threading.Thread(target=run,args=('t1',))
#     t.setDaemon(True)
#     t.start()
#     t.join()
#     print('end')


import threading
import time

#
# def child_thread1():
#     for i in range(10):
#         time.sleep(1)
#         print('子线程开始运行')
#
#
# def parent_thread():
#     print('父线程开始运行')
#     thread1 = threading.Thread(target=child_thread1)
#     # thread1.setDaemon(True)
#     thread1.start()
#     print('父线程结束运行')
#
#
# if __name__ == "__main__":
#     parent_thread()


import threading
import time

# thread1是守护线程，thread2非守护线程，因此，进程会等待thread2完成后结束，而不会等待thread1完成,
# 所以当thread2运行完成后，thread1也随之结束
# def child_thread1():
#     for i in range(100):
#         time.sleep(1)
#         print('子线程1开始运行')
#
#
# def child_thread2():
#     for i in range(5):
#         time.sleep(1)
#         print('子线程2开始运行')
#
#
# def parent_thread():
#     print('父线程开始运行')
#     thread1 = threading.Thread(target=child_thread1)
#     thread2 = threading.Thread(target=child_thread2)
#     thread1.setDaemon(True)
#     thread1.start()
#     thread2.start()
#     print('父线程结束运行')
#
#
# if __name__ == "__main__":
#     parent_thread()

import threading
import time


def run(n):
    """
    主线程启动50个子线程，但每个次运行时，主线程运行时间低于2s，因此所有子线程（守护线程）不会走到print("task has done!")
    """
    print("task", n)
    time.sleep(2)
    print("task has done!")


start_time = time.time()
for i in range(50):
    #若使主线程运行时间大于2s，子线程如果在1s内可以完成print("task has done!")，那么将会全部打印
    # time.sleep(3)
    t = threading.Thread(target=run, args=("t-%s" % i,))
    t.setDaemon(True)  # 把当前线程设置为守护线程，一定在start前设置
    t.start()
print(threading.current_thread().getName(), threading.active_count())
print(time.time() - start_time)
