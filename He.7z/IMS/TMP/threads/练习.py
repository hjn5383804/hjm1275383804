# #!/usr/bin/python3
import threading


# from IMS.COM.TMP.W36_telnet import telnet_36
# import time
#
#
# # 子线程
# def req(cmd, ip):
#     res = telnet_36(cmd, ip)
#     return res
#
# class MyThread(threading.Thread):
#     def __init__(self, cmd, ip):
#         super(MyThread, self).__init__()
#         self.cmd = cmd
#         self.ip = ip
#
#     # 父线程
#     def run(self):
#         threadLock = threading.Lock()
#         threadLock.acquire()
#         print(req(self.cmd, self.ip))
#         threadLock.release()
#
# # 创建新线程(无序执行)
# thread1 = MyThread('ifconfig br0', '192.168.1.102')
# thread2 = MyThread('ifconfig eth0', '192.168.1.102')
# thread3 = MyThread('ifconfig wlan0', '192.168.1.102')
# thread4 = MyThread('ifconfig wlan1', '192.168.1.102')
#
# # 开启新线程
# thread_list = [thread1, thread2, thread3, thread4]
# start_time = time.time()
# for i in thread_list:
#     i.start()
#
# for i in thread_list:
#     i.join()
#
# print(time.time() - start_time)


# start_time1=time.time()
# telnet_36('ifconfig br0', '192.168.1.102')
# telnet_36('ifconfig eth0', '192.168.1.102')
# telnet_36('ifconfig wlan0', '192.168.1.102')
# telnet_36('ifconfig wlan1', '192.168.1.102')
# print(time.time() - start_time1)




# import threading
#
# def action(count):
#     for i in range(count):
#         print(threading.current_thread().getName() + "," + str(i))
#
# def main():
#     t1 = threading.Thread(target=action, args=(10,))
#     # 设置子线程为守护进程
#     t1.setDaemon(True)
#     t1.start()
#     t1.join()
#     # time.sleep(1)
#     for i in range(3):
#         print(threading.current_thread().getName()+','+str(i))
# #子线程与主线程并发执行，子线程只能在主线程执行完成前运行，当主线程完成遍历打印动作后，不再等待子线程后续未完成的遍历，直接强制退出守护线程
#
# if __name__ == "__main__":
#     main()


# import threading,time
# def run(n):
#     print("task ",n)
#     time.sleep(2)
#
# start_time=time.time()
# t_obj=[]
# for i in range(1,51):
#     t=threading.Thread(target=run,args=("t- %s"%i,))
#     t_obj.append(t)
#     t.start()
#
# for t in t_obj:
#     t.join()
#
#
# print("cost  :" ,time.time()-start_time)
#
# import threading
# import time
# #sleep(2)期间，主线程已经运行完毕，所有子线程强制关闭
# def run(n):
#     print("task",n)
#     time.sleep(2)
#     print("task has done!")
# start_time=time.time()
# for i in range(10):
#     t=threading.Thread(target=run,args=("t-%s"%i,))
#     t.setDaemon(True)
#     t.start()
# print("当前线程变量：",threading.current_thread(),"正在运行线程数的量:",threading.active_count())
# print(time.time()-start_time)


