# #!/usr/bin/python3
import threading
import time

exitFlag = 0


# threading.currentThread(): 返回当前的线程变量。
# threading.enumerate(): 返回一个包含正在运行的线程的list。正在运行指线程启动后、结束前，不包括启动前和终止后的线程。
# threading.activeCount(): 返回正在运行线程数的量，与len(threading.enumerate())有相同的结果。
# run(): 用以表示线程活动的方法。
# start():启动线程活动。
# join([time]): 优先让该方法的调用者使用 CPU 资源,直至线程的join() 方法被调用中止-正常退出或者抛出未处理的异常-或者是可选的超时发生。
# isAlive(): 返回线程是否活动的。
# getName(): 返回线程名。
# setName(): 设置线程名

# 子线程
# def print_time(threadName, delay, counter):
#     while counter > 0:
#         if exitFlag:
#             threadName.exit()
#         time.sleep(delay)
#         print("%s: %s" % (threadName, time.ctime(time.time())))
#         counter -= 1
#
#
# class myThread(threading.Thread):
#     def __init__(self, name, delay):
#         super(myThread, self).__init__()
#         self.name = name
#         self.delay = delay
#
#     # 父线程:创建子线程，完成5此循环的子线程自动退出
#     def run(self):
#         print("开始线程：" + self.name)
#         print_time(self.name, self.delay, 5)
#         print("退出线程：" + self.name)
#
# if __name__ == '__main__':
#     # 创建新线程
#     thread1 = myThread("Thread-1", 1)
#     thread2 = myThread("Thread-2", 2)
#     thread3 = myThread("Thread-3", 3)
#     # 开启新线程
#     thread_list = [thread1, thread2, thread3]
#     #同时起3个线程
#     for i in thread_list:
#         i.start()
#     for i in thread_list:
#         i.join()
#     print("退出主线程")


# import threading,time
# class MyThread(threading.Thread):
#     def __init__(self,n):
#         super(MyThread, self).__init__()
#         self.n=n
#     def run(self):
#         print("run task",self.n)
#         time.sleep(2)
#         print("task done,",self.n)
#
#
# t1=MyThread("t1")
# t2=MyThread("t2")
#
# x=time.time()
# t1.start()
# t2.start()
# t1.join()  #wait()  第一个线程执行完毕后再执行第二个线程
# t2.join()
# print(time.time()-x)

import threading,time
def run(n):
    print("task ",n)
    time.sleep(2)

start_time=time.time()
t_obj=[]
for i in range(500):
    t=threading.Thread(target=run,args=("t- %s"%i,))
    t_obj.append(t)
    t.start()

for t in t_obj:
    t.join()


print("cost  :" ,time.time()-start_time)
