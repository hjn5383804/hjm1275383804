import threading, time

num = 0
num2 = 0


def run1():
    print("抓取第1部分数据")
    lock.acquire()
    global num
    num += 1
    lock.release()
    return num


def run2():
    print("抓取第2部分数据")
    lock.acquire()
    global num2
    num2 += 1
    lock.release()
    return num2


def run3():
    lock.acquire()
    res = run1()
    print('*****************')
    res2 = run2()
    lock.release()
    print("res:",res,"res2", res2)


# 普通的锁，在多个锁的情况下，无法找到对应的钥匙，而使用Rlock可以

if __name__ == '__main__':

    lock = threading.RLock()  # RLOCK
    for i in range(10):
        t = threading.Thread(target=run3)
        t.start()
while threading.active_count() != 1:
    print(threading.active_count())
    pass
else:
    print('----all threads done---')
    print("num",num, "num2",num2)
