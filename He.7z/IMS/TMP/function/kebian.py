#对于不可变量如果需要创建的对象的内容(value值)相同，则引用都指向同一个对象，不创建新的内存空间
import random
#不可变数据类型有字符串、元组、整形


list1=[1,2,3,4,5]
list2=[1,2,3,4,5]
print(id(list1))
print(id(list2))



str1="a"
str2='a'

print(id(str1))
print(id(str2))

#
#
def f1(x,*args):
    # *代表允许你传入0个或任意个参数，这些可变参数在函数调用时自动组装为一个tuple
    print(x)
    if args:
        print(args)
f1(1,[1,2,3,4,5])

#
# def f2(x,**kwargs):
#     print(x)
#     if kwargs:
#         print(kwargs)
# f2(8,a=1,b=2,c=3)
#
# dict1={'a': 1, 'b': 2, 'c': 3}
#
# f2(111,**dict1)
# # print(*dict1)

#
# name='zhangsan'
# print(name[2:5])
# print(name[:5])
# print(name[2::])
# def a():
#     return {"login":{
#         "a":1,
#         "b":2
#     }}
#
# dict1=a()
# print(type(dict1))
# dict2={}
# print(type(dict2))
# dict2.update(a())
# print(dict1)
# print(dict2)
# x= {'datetime': {'sys_date': '2021-08-31', 'sys_time': '00:32'}, 'local': {'timezone': 8}, 'srv': {'enable': False, 'ntp': None} }
# print(type(x))
# x=str(x)
# print(type(x))
# x.replace("'",'"')
# print(x)
# # x={
# #     "data":
# #         {
# #             'datetime': {'sys_date': '2021-08-31', 'sys_time': '00:32'},
# #             'local': {'timezone': 8},
# #             'srv': {'enable': False, 'ntp': None}
# #     }
# # }
# x={"data":{'datetime': {'sys_date': '2021-08-31', 'sys_time': '00:32'}, 'local': {'timezone': 8},'srv': {'enable': False, 'ntp': None} } }

#定义一个函数，需要传参一个列表
# def f(list):
#     list.append('a')
#     return list
# print(f([1]))