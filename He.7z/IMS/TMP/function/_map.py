import math


def y(x):
    return x**x
print(list(map(y,[1,3,5,7])))


print(list(map(lambda x:x**x,[1,3,5,7])))


# rectangle = Rectangle(200,100)
# print(math.sqrt(10000000000))
print(sum(iter(range(6,99999,3))))
print(sum(iter(range(6,12,3))))
print(33334*3)
