#coding=utf-8
from functools import reduce

def add(x, y) :
    return x + y
sum1 = reduce(add, [1,2,3,4,5])   # 计算列表和：1+2+3+4+5





sum2 = reduce(lambda x, y: x+y, [1,2,3,4,5])  # 使用 lambda 匿名函数
print(sum1)
print(sum2)


sum3=reduce(lambda x,y:x*y,range(1,6))
print(sum3)

def x(n,m):
    return n*m
def count(n,m):
    return reduce(x,range(n,m+1))


print(count(4,6))
# print(reduce(x,[1,2,3,4,5]))