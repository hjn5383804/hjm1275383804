a=input("input:")
print(type(a))