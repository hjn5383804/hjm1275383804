#coding=gbk
"""���ܼ��������ֿ������������������򵥵ķ�ʽ��������ı���"""

# class Parrot(object):
#     def __init__(self):
#         self._voltage = 100000
#
#     @property
#     def voltage1(self):
#         """Get the current voltage."""
#         return self._voltage
# print(Parrot().voltage1)



class C(object):
    def __init__(self):
        self._x = None
    @property
    def x(self):
        """���ڻ�ȡx"""
        return self._x
    @x.setter
    def x(self, value):
        """�����޸�x"""
        self._x = value
    @x.deleter
    def x(self):
        """����ɾ��x"""
        del self._x
X=C()
print(X.x)
X.x=1024
print(X.x)
del X.x
print(X.x)






# class Age(object):
#
#     @property
#     def birth(self):
#         return self._birth
#
#     @birth.setter
#     def birth(self, value):
#         """�ɶ�д����"""
#         self._birth = value
#
#     @property
#     def age(self):
#         """����setter��ֻ������"""
#         return 2021 - self._birth
#
# x=Age()
# x._birth=1999
# print(x._birth)
# print(x.age)
#
#
#
# class Student(object):
#
#     @property
#     def score(self):
#         return self._score
#
#     @score.setter
#     def score(self, value):
#         if not isinstance(value, int):
#             raise ValueError('score must be an integer!')
#         if value < 0 or value > 100:
#             raise ValueError('score must between 0 ~ 100!')
#         self._score = value
#
#
#
#
# class Screen(object):
#     @property
#     def width(self):
#       return self._width
#
#     @width.setter
#     def width(self,width):
#       self._width=width
#
#     @property
#     def height(self):
#       return self._height
#     @height.setter
#     def height(self,height):
#       self._height=height
#
#     @property
#     def resolution(self):
#       return self._height*self._width
#
# s = Screen()
# print(s.width)
# print(s.height)
#
# s.width = 1024
# s.height = 768
# print('resolution =', s.resolution)
#
