#coding=gbk
x="print('abc')"
exec(x)

x="for i in range(10):print(i)"
exec(x)

